## UMP-CAMUNDA-BACKEND-TEMPLATE
### Версии могут быть неактуальны

---

## Полезные ссылки
Документация: https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1712214062

---

## Описание
Скелет backend сервиса, используется для быстрого старта разработки.

Описаны все необходимые зависимости и структура проекта для работы с CAMUNDA.

---
