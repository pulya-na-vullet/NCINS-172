plugins {
    id("ru.alfabank.ump.ump-microservice-plugin") version "4.0.4"
    id("com.diffplug.spotless") version "8.4.0"
}

configurations.all {
    exclude(group = "commons-logging", module = "commons-logging")
}

group = "ru.alfabank.ump"

val instancioVersion = "4.8.0"
val utilityLibVersion = "2.0.0"
val resilience4jVersion = "2.2.0"
val camundaStarterVersion = "0.1.0"
val camundaTestVersion = "8.7.20"
val netty = "4.1.135.Final"
val umpApplicationFacadeVersion = "4.2.77"
val nibNcinsAccApiVersion = "0.3.0-test-SNAPSHOT-64"
val authClientVersion = "2.2.0"
val umpProductsVersion = "4.2.53";

microservice {
    dependencyPack
        .microservice()
        .lombok()
        .mapstruct()
}

repositories {
    maven("https://binary.alfabank.ru/artifactory/public")
    maven("https://binary.alfabank.ru/artifactory/ump-mvn-releases")
}

tasks.dockerCreateDockerfile {
    runCommand(
        "echo \"https://binary.alfabank.ru/artifactory/alpine-mirror/v3.24/main\" > /etc/apk/repositories"
                + " && apk --no-cache add --upgrade libssl3 libcrypto3 musl musl-utils zlib"
    )
}

dependencies {
    //common
    implementation("ru.alfabank.ump:ump-utility-lib:2.0.0")
    implementation("org.springframework.cloud:spring-cloud-starter-openfeign")
    implementation("ru.alfalab.starter.logging:spring-boot-starter-alfalab-logging")
    implementation("io.github.resilience4j:resilience4j-spring-boot3:2.2.0")
    implementation("ru.alfabank.ump:ump-auth-client:${authClientVersion}")

    //camunda
    implementation("ru.alfabank.ump:ump-camunda-starter:${camundaStarterVersion}")

    implementation("ump.alfabank.contracts:applicationfacade-api:${umpApplicationFacadeVersion}")
    implementation("ru.alfabank.corp.openapi.ncins.acc:corp-ncins-acc-api-spring-stubs:${nibNcinsAccApiVersion}")
    implementation("ump.alfabank.contracts:products-api:${umpProductsVersion}")

    implementation("io.github.openfeign:feign-okhttp")

    implementation("io.netty:netty-codec-http:${netty}")
    implementation("io.netty:netty-codec-http2:${netty}")
    implementation("io.netty:netty-handler-proxy:${netty}")
    implementation("io.netty:netty-handler:${netty}")
    implementation("io.netty:netty-codec:${netty}")
    implementation("commons-beanutils:commons-beanutils:1.11.0")

    //test
    testImplementation("org.instancio:instancio-junit:4.8.0")
    testImplementation("io.camunda:spring-boot-starter-camunda-test:${camundaTestVersion}")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.springframework.cloud:spring-cloud-contract-wiremock")
}

quality {
    strict = false
}

spotless {
    java {
        googleJavaFormat("1.22.0")
            .aosp()
    }
}

tasks.jacocoTestReport {
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}