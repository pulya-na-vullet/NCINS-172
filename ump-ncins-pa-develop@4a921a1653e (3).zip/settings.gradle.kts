pluginManagement {
    repositories {
        maven("https://binary.alfabank.ru/artifactory/public")
        maven("https://binary.alfabank.ru/artifactory/gradleplugins")
    }
}

rootProject.name = "ump-ncins-pa"
