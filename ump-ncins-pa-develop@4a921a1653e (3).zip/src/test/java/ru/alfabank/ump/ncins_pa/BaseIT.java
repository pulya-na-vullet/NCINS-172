package ru.alfabank.ump.ncins_pa;

import com.github.tomakehurst.wiremock.client.WireMock;
import io.camunda.zeebe.spring.test.ZeebeSpringTest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.hc.core5.http.HttpHeaders;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest
@ZeebeSpringTest
public abstract class BaseIT {

    protected final void tokenReceiveOkStub() throws IOException {
        var response = getFile("keycloak/keycloak_ok_response.json");
        WireMock.stubFor(
                WireMock.post(
                                WireMock.urlPathEqualTo(
                                        "/auth/realms/test/protocol/openid-connect/token"))
                        .willReturn(
                                WireMock.aResponse()
                                        .withStatus(HttpStatus.OK.value())
                                        .withHeader(
                                                HttpHeaders.CONTENT_TYPE,
                                                MediaType.APPLICATION_JSON_VALUE)
                                        .withBody(response)));
    }

    protected final String getFile(String filePath) throws IOException {
        return new ClassPathResource(String.format("stubs/%s", filePath))
                .getContentAsString(StandardCharsets.UTF_8);
    }
}
