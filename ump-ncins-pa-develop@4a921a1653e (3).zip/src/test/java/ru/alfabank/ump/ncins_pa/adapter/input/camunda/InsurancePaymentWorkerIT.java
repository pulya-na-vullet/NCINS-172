package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import ru.alfabank.ump.ncins_pa.BaseIT;
import ru.alfabank.ump.ncins_pa.usecase.port.input.PaymentInputPort;
import ru.alfabank.ump.ncins_pa.usecase.service.PaymentService;

@DisplayName("PaymentWorkerIT - Интеграционное тестирование воркера")
class InsurancePaymentWorkerIT extends BaseIT {

    private static final UUID BUSINESS_KEY =
            UUID.fromString("550e8400-e29b-41d4-a716-446655110000");
    private static final long PROCESS_INSTANCE_KEY = 12345L;

    @Mock private ActivatedJob job;
    @Autowired private InsurancePaymentWorker insurancePaymentWorker;
    @MockitoSpyBean private PaymentInputPort paymentInputPort;

    @Test
    @DisplayName("Должен успешно установить Hold по счету")
    void shouldSetHoldSuccessfully() {
        Map<String, Object> variables =
                Map.of(
                        "businessKey", "550e8400-e29b-41d4-a716-446655110003",
                        "productCode", "NON_INSURANCE_CODE",
                        "systemCode", "SFA");
        when(paymentInputPort.setHold(any())).thenReturn(new PaymentService.SetHoldDto());
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        assertDoesNotThrow(() -> insurancePaymentWorker.setHold(BUSINESS_KEY, variables, job));

        verify(paymentInputPort, times(1)).setHold(variables);
    }

    @Test
    @DisplayName(
            "Должен корректно обрабатывать пустые переменные во время установки установить Hold по счету")
    void shouldHandleEmptyVariables_whenSetHold() {
        Map<String, Object> variables = Map.of();
        when(paymentInputPort.setHold(any())).thenReturn(new PaymentService.SetHoldDto());
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        assertDoesNotThrow(() -> insurancePaymentWorker.setHold(BUSINESS_KEY, variables, job));

        verify(paymentInputPort).setHold(variables);
    }

    @Test
    @DisplayName("Должен успешно создать платежное поручение")
    void shouldPaySuccessfully() {
        Map<String, Object> variables =
                Map.of(
                        "businessKey", "550e8400-e29b-41d4-a716-446655110003",
                        "productCode", "NON_INSURANCE_CODE",
                        "systemCode", "SFA");
        when(paymentInputPort.createPayment(any()))
                .thenReturn(new PaymentService.CreatePaymentDto());
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        assertDoesNotThrow(
                () -> insurancePaymentWorker.createPayment(BUSINESS_KEY, variables, job));

        verify(paymentInputPort, times(1)).createPayment(variables);
    }

    @Test
    @DisplayName("Должен корректно обрабатывать пустые переменные при создани платёжного поручения")
    void shouldHandleEmptyVariables_whereCreatePayment() {
        Map<String, Object> variables = Map.of();
        when(paymentInputPort.createPayment(any()))
                .thenReturn(new PaymentService.CreatePaymentDto());
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        assertDoesNotThrow(
                () -> insurancePaymentWorker.createPayment(BUSINESS_KEY, variables, job));

        verify(paymentInputPort).createPayment(variables);
    }
}
