package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.ACCOUNT_DOCUMENT_TYPE;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.APPLICATION_SERVICE_CODE;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.PRODUCT_CODE;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import java.time.OffsetDateTime;
import java.util.Base64;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.PrepareDataForPrintFormInputOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.PrepareDataForPrintFormInputVariables;

@DisplayName(
        "PrepareDataForPrintFormWorkerIT - Интеграционное тестирование \"Подготовить данные для ПФ\"")
@ExtendWith(MockitoExtension.class)
class PrepareDataForPrintFormWorkerIT {

    @Mock private ActivatedJob job;

    @InjectMocks private PrepareDataForPrintFormWorker worker;

    private static final UUID BUSINESS_KEY =
            UUID.fromString("550e8400-e29b-41d4-a716-446655110000");
    private static final long PROCESS_INSTANCE_KEY = 12345L;

    @Test
    @DisplayName("Должен успешно подготовить данные для печатной формы")
    void shouldPrepareDataForPrintFormSuccessfully() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        // when
        PrepareDataForPrintFormInputOutputVariables result =
                worker.prepareDataForPrintForm(BUSINESS_KEY, input, job);

        // then
        assertNotNull(result);
        assertEquals(BUSINESS_KEY, result.serviceId());
        assertEquals(APPLICATION_SERVICE_CODE, result.serviceCode());
        assertEquals(PRODUCT_CODE, result.productCode());
        assertNotNull(result.documents());
        assertEquals(1, result.documents().size());

        var document = result.documents().get(0);
        assertEquals(ACCOUNT_DOCUMENT_TYPE, document.documentType());
        assertFalse(document.isWriteInEa());
        assertNotNull(document.reportData());

        // Проверяем, что reportData — это base64 от XML
        String decodedXml = new String(Base64.getDecoder().decode(document.reportData()), UTF_8);
        assertNotNull(decodedXml);
        org.assertj.core.api.Assertions.assertThat(decodedXml)
                .contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
                .contains("<datasource>")
                .contains("</datasource>")
                .contains("<contractNumber>NC-2025-001</contractNumber>")
                .contains("<fullName>Иванов Иван Иванович</fullName>")
                .contains("<inn>123456789012</inn>")
                .contains("<email>ivanov@example.com</email>")
                .contains("<paymentAccount>40817810000000000001</paymentAccount>")
                .contains("<insuranceSum>1000000.00</insuranceSum>")
                .contains("<insurancePremium>50000.00</insurancePremium>");
    }

    @Test
    @DisplayName("Должен корректно обрабатывать дробные числа")
    void shouldHandleDoubleValues() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Тест",
                        "123456789012",
                        "test@example.com",
                        "NC-001",
                        OffsetDateTime.parse("2025-06-15T10:30:00+03:00"),
                        OffsetDateTime.parse("2026-06-15T10:30:00+03:00"),
                        "2025-06-15",
                        1234567.89,
                        98765.43,
                        "40817810000000000002");

        // when
        PrepareDataForPrintFormInputOutputVariables result =
                worker.prepareDataForPrintForm(BUSINESS_KEY, input, job);

        // then
        assertNotNull(result);
        String decodedXml =
                new String(
                        Base64.getDecoder().decode(result.documents().get(0).reportData()), UTF_8);
        org.assertj.core.api.Assertions.assertThat(decodedXml)
                .contains("<insuranceSum>1234567.89</insuranceSum>")
                .contains("<insurancePremium>98765.43</insurancePremium>");
    }

    // ========================================================================
    // Тесты на валидацию входных данных (PrepareDataForPrintFormValidator)
    // ========================================================================

    @Test
    @DisplayName("Должен выбросить NPE при null inputVariables")
    void shouldThrowNpeWhenInputVariablesIsNull() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, null, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("prepareDataForPrintFormInputVariables");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null programId")
    void shouldThrowNpeWhenProgramIdIsNull() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        null,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("programId");
    }

    @Test
    @DisplayName("Должен выбросить RuntimeException при blank fullName")
    void shouldThrowExceptionWhenFullNameIsBlank() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("fullName");
    }

    @Test
    @DisplayName("Должен выбросить RuntimeException при blank inn")
    void shouldThrowExceptionWhenInnIsBlank() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "   ",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("inn");
    }

    @Test
    @DisplayName("Должен выбросить RuntimeException при blank email")
    void shouldThrowExceptionWhenEmailIsBlank() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        null,
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("email");
    }

    @Test
    @DisplayName("Должен выбросить RuntimeException при blank contractNumber")
    void shouldThrowExceptionWhenContractNumberIsBlank() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("contractNumber");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null beginDate")
    void shouldThrowNpeWhenBeginDateIsNull() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        null,
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("beginDate");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null endDate")
    void shouldThrowNpeWhenEndDateIsNull() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        null,
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("endDate");
    }

    @Test
    @DisplayName("Должен выбросить RuntimeException при blank currentDate")
    void shouldThrowExceptionWhenCurrentDateIsBlank() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "   ",
                        1000000.0,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("currentDate");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null insuranceSum")
    void shouldThrowNpeWhenInsuranceSumIsNull() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        null,
                        50000.0,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("insuranceSum");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null insurancePremium")
    void shouldThrowNpeWhenInsurancePremiumIsNull() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        null,
                        "40817810000000000001");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("insurancePremium");
    }

    @Test
    @DisplayName("Должен выбросить RuntimeException при blank paymentAccount")
    void shouldThrowExceptionWhenPaymentAccountIsBlank() {
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input =
                new PrepareDataForPrintFormInputVariables(
                        1,
                        "Иванов Иван Иванович",
                        "123456789012",
                        "ivanov@example.com",
                        "NC-2025-001",
                        OffsetDateTime.parse("2025-01-01T00:00:00+03:00"),
                        OffsetDateTime.parse("2026-01-01T00:00:00+03:00"),
                        "2025-01-15",
                        1000000.0,
                        50000.0,
                        "");

        assertThatThrownBy(() -> worker.prepareDataForPrintForm(BUSINESS_KEY, input, job))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("paymentAccount");
    }
}
