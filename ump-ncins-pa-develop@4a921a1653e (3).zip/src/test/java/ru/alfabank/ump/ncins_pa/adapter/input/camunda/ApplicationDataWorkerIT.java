package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import java.io.IOException;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import ru.alfabank.ump.ncins_pa.BaseIT;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ApplicationDataOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;

@AutoConfigureWireMock(port = 0)
@DisplayName("SigningDataPreparationWorkerIT - Интеграционное тестирование воркера")
class ApplicationDataWorkerIT extends BaseIT {
    @Autowired private ApplicationDataWorker worker;

    @Test
    @DisplayName("Должен успешно получить параметры клиента")
    void shouldGetApplicationDataSuccessfully() throws IOException {
        UUID businessKey = UUID.fromString("550e8400-e29b-41d4-a716-446655110003");

        String responseBody = getFile("ump/ump_application_response_200.json");

        stubFor(
                get(urlPathEqualTo("/applications/" + businessKey))
                        .withQueryParam("include", equalTo("PARTICIPANT"))
                        .withQueryParam("include", equalTo("PRODUCT"))
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withHeader("Content-Type", "application/json")
                                        .withBody(responseBody)));

        ActivatedJob activatedJob = mock(ActivatedJob.class);
        when(activatedJob.getProcessInstanceKey()).thenReturn(6755399708239919L);

        String proccessType = "FINALISATION";

        ApplicationDataOutputVariables result =
                assertDoesNotThrow(
                        () -> worker.getApplicationData(businessKey, proccessType, activatedJob));

        assertNotNull(result);
        assertEquals(ResponseCode.SUCCESS, result.getProcessParams());

        verify(getRequestedFor(urlPathEqualTo("/applications/" + businessKey)));
    }
}
