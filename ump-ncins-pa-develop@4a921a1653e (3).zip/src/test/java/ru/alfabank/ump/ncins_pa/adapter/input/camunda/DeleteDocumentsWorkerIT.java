package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import ru.alfabank.ump.ncins_pa.BaseIT;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentResponseOutputVariables;

@AutoConfigureWireMock(port = 0)
class DeleteDocumentsWorkerIT extends BaseIT {

    private static final UUID BUSINESS_KEY =
            UUID.fromString("550e8400-e29b-41d4-a716-446655110000");
    private static final long PROCESS_INSTANCE_KEY = 12345L;

    @Mock private ActivatedJob job;

    @Autowired private DeleteDocumentsWorker deleteDocumentsWorker;

    @Test
    @DisplayName("Должен успешно удалить документ")
    void shouldDeleteDocumentSuccessfully() {
        DocumentDto document = new DocumentDto("https://example.com/doc/123");
        Map<String, Object> expectedResult = Map.of("status", "1");

        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        DocumentResponseOutputVariables result =
                assertDoesNotThrow(
                        () -> deleteDocumentsWorker.deleteDocument(BUSINESS_KEY, document, job));
        assertEquals(expectedResult, result.documentResponse());
    }
}
