package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.ERROR;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.SUCCESS;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ACDocumentDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductDataUpdateInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductDataUpdateOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.ProductsMapper;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ProductsOutputPort;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductDto;
import ump.products.api.dto.ProductNonCreditInsuranceDto;

@DisplayName(
        "ProductDataUpdateWorkerIT - Интеграционное тестирование \"Обновление данных по продукту\"")
@ExtendWith(MockitoExtension.class)
class ProductDataUpdateWorkerIT {

    @Mock private ProductsOutputPort productsOutputPort;
    @Mock private ProductsMapper productsMapper;
    @Mock private ActivatedJob job;

    @InjectMocks private ProductDataUpdateWorker worker;

    private static final UUID BUSINESS_KEY =
            UUID.fromString("550e8400-e29b-41d4-a716-446655110000");
    private static final long PROCESS_INSTANCE_KEY = 12345L;
    private static final UUID PRODUCT_ID = UUID.fromString("660e8400-e29b-41d4-a716-446655110001");
    private static final UUID AC_ID = UUID.fromString("770e8400-e29b-41d4-a716-446655110002");

    private ProductDataUpdateInputVariables createValidInput() {
        var acDocument = new ACDocumentDto("CONTRACT_ACCOUNT_BLOCK", AC_ID);
        var productInfo = new ProductDto();
        return new ProductDataUpdateInputVariables(PRODUCT_ID, List.of(acDocument), productInfo);
    }

    private ProductNonCreditInsuranceDto createProductNonCreditInsuranceDto() {
        var dto = new ProductNonCreditInsuranceDto();
        dto.setPolicyLink("old-policy-link");
        return dto;
    }

    private ProductCommonParamDto createProductCommonParamDto() {
        var dto = new ProductCommonParamDto();
        dto.setProductProperties(createProductNonCreditInsuranceDto());
        return dto;
    }

    @Test
    @DisplayName("Должен успешно обновить данные по продукту и вернуть SUCCESS")
    void shouldUpdateProductDataSuccessfully() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input = createValidInput();
        var productCommonParamDto = createProductCommonParamDto();
        var productNonCreditInsuranceDto =
                (ProductNonCreditInsuranceDto) productCommonParamDto.getProductProperties();

        when(productsMapper.toProductCommonParamDto(input.productInfo()))
                .thenReturn(productCommonParamDto);

        var expectedPutProduct = new ProductDto();
        when(productsOutputPort.putProduct(
                        eq(PRODUCT_ID),
                        eq(productCommonParamDto),
                        eq(String.valueOf(PROCESS_INSTANCE_KEY))))
                .thenReturn(expectedPutProduct);

        // when
        ProductDataUpdateOutputVariables result =
                worker.productDataUpdate(BUSINESS_KEY, input, job);

        // then
        assertNotNull(result);
        assertEquals(SUCCESS, result.getProcessParams());

        // Проверяем, что policyLink установлен из acId
        assertEquals(AC_ID.toString(), productNonCreditInsuranceDto.getPolicyLink());

        verify(productsMapper).toProductCommonParamDto(input.productInfo());
        verify(productsOutputPort)
                .putProduct(
                        eq(PRODUCT_ID),
                        eq(productCommonParamDto),
                        eq(String.valueOf(PROCESS_INSTANCE_KEY)));
    }

    @Test
    @DisplayName("Должен вернуть ERROR при исключении в productsOutputPort.putProduct")
    void shouldReturnErrorWhenPutProductThrowsException() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var input = createValidInput();
        var productCommonParamDto = createProductCommonParamDto();

        when(productsMapper.toProductCommonParamDto(input.productInfo()))
                .thenReturn(productCommonParamDto);

        when(productsOutputPort.putProduct(
                        eq(PRODUCT_ID),
                        eq(productCommonParamDto),
                        eq(String.valueOf(PROCESS_INSTANCE_KEY))))
                .thenThrow(new RuntimeException("Ошибка при обновлении продукта"));

        // when
        ProductDataUpdateOutputVariables result =
                worker.productDataUpdate(BUSINESS_KEY, input, job);

        // then
        assertNotNull(result);
        assertEquals(ERROR, result.getProcessParams());
    }

    // ========================================================================
    // Тесты на валидацию входных данных (ProductDataUpdateValidator)
    // ========================================================================

    @Test
    @DisplayName("Должен выбросить NPE при null inputVariables")
    void shouldThrowNpeWhenInputVariablesIsNull() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        // when & then
        assertThatThrownBy(() -> worker.productDataUpdate(BUSINESS_KEY, null, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("productDataUpdateInputVariables");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null productId")
    void shouldThrowNpeWhenProductIdIsNull() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var acDocument = new ACDocumentDto("CONTRACT_ACCOUNT_BLOCK", AC_ID);
        var productInfo = new ProductDto();
        var input = new ProductDataUpdateInputVariables(null, List.of(acDocument), productInfo);

        // when & then
        assertThatThrownBy(() -> worker.productDataUpdate(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("productId");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null acDocuments")
    void shouldThrowNpeWhenAcDocumentsIsNull() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var productInfo = new ProductDto();
        var input = new ProductDataUpdateInputVariables(PRODUCT_ID, null, productInfo);

        // when & then
        assertThatThrownBy(() -> worker.productDataUpdate(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("acDocuments");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null acId в acDocuments")
    void shouldThrowNpeWhenAcIdIsNull() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var acDocument = new ACDocumentDto("CONTRACT_ACCOUNT_BLOCK", null);
        var productInfo = new ProductDto();
        var input =
                new ProductDataUpdateInputVariables(PRODUCT_ID, List.of(acDocument), productInfo);

        // when & then
        assertThatThrownBy(() -> worker.productDataUpdate(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("acId");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null type в acDocuments")
    void shouldThrowNpeWhenTypeIsNull() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var acDocument = new ACDocumentDto(null, AC_ID);
        var productInfo = new ProductDto();
        var input =
                new ProductDataUpdateInputVariables(PRODUCT_ID, List.of(acDocument), productInfo);

        // when & then
        assertThatThrownBy(() -> worker.productDataUpdate(BUSINESS_KEY, input, job))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("type");
    }

    @Test
    @DisplayName("Должен выбросить NPE при null productInfo")
    void shouldThrowNpeWhenProductInfoIsNull() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var acDocument = new ACDocumentDto("CONTRACT_ACCOUNT_BLOCK", AC_ID);
        var input = new ProductDataUpdateInputVariables(PRODUCT_ID, List.of(acDocument), null);

        // when & then
        assertThatThrownBy(() -> worker.productDataUpdate(BUSINESS_KEY, input, job))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("productInfo");
    }
}
