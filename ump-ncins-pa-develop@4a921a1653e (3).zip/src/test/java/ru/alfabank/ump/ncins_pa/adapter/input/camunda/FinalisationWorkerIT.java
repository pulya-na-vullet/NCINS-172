package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.stubbing.Scenario;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import java.io.IOException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.InsuranceObjectDto;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.RealEstateTypeDto;
import ru.alfabank.ump.ncins_pa.BaseIT;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ContractCreateInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.FinalisationDataOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@AutoConfigureWireMock(port = 0)
@DisplayName("FinalisationWorkerIT - Интеграционное тестирование воркера")
class FinalisationWorkerIT extends BaseIT {

    private static final UUID BUSINESS_KEY =
            UUID.fromString("550e8400-e29b-41d4-a716-446655110000");
    private static final long PROCESS_INSTANCE_KEY = 12345L;
    private static final String STATE_AFTER_401 = "After 401 Response";

    @Mock private ActivatedJob job;

    @Autowired private FinalisationWorker finalisationWorker;

    @BeforeEach
    void resetWireMock() {
        WireMock.reset();
    }

    @Test
    @DisplayName("Должен успешно выполнить сохранение контракта во внешнем mock сервисе")
    void shouldCreateContractSuccessfully() throws IOException {
        tokenReceiveOkStub();

        stubFor(
                post(urlPathEqualTo("/v1/ins-contracts"))
                        .willReturn(
                                aResponse()
                                        .withStatus(201)
                                        .withHeader("Content-Type", "application/json")
                                        .withBody("{}")));

        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        ContractCreateInputVariables variables = createValidVariables();

        FinalisationDataOutputVariables result =
                assertDoesNotThrow(
                        () -> finalisationWorker.createContract(BUSINESS_KEY, variables, job));

        assertNotNull(result);
        assertNull(result.errorMessage());
        assertEquals(ResponseCode.SUCCESS, result.result());

        verify(
                postRequestedFor(urlPathEqualTo("/v1/ins-contracts"))
                        .withHeader("A-customerId", equalTo("AAAX22"))
                        .withHeader("A-userId", equalTo("AAAX22"))
                        .withHeader("A-clientType", equalTo("BACKEND"))
                        .withHeader("A-channelId", equalTo("ump")));
    }

    @Test
    @DisplayName("Должен произвести 3 ретрая и вернуть ошибку при 5xx от внешнего mock сервиса")
    void shouldReturnErrorWhenExternalServiceReturns500() throws IOException {
        tokenReceiveOkStub();
        stubFor(post(urlPathEqualTo("/v1/ins-contracts")).willReturn(aResponse().withStatus(503)));
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        ContractCreateInputVariables variables = createValidVariables();

        FinalisationDataOutputVariables result =
                assertDoesNotThrow(
                        () -> finalisationWorker.createContract(BUSINESS_KEY, variables, job));

        assertNotNull(result);
        assertEquals(ResponseCode.ERROR, result.result());
        assertNotNull(result.errorMessage());

        verify(3, postRequestedFor(urlPathEqualTo("/v1/ins-contracts")));
    }

    @Test
    @DisplayName("Должен автоматически обновить токен и повторить запрос при 401")
    void shouldRetryWithNewTokenOn401() throws IOException {
        tokenReceiveOkStub();

        stubFor(
                post(urlPathEqualTo("/v1/ins-contracts"))
                        .inScenario("Token Refresh Scenario")
                        .whenScenarioStateIs(Scenario.STARTED)
                        .willReturn(
                                aResponse()
                                        .withStatus(401)
                                        .withHeader("Content-Type", "application/json"))
                        .willSetStateTo(STATE_AFTER_401));

        stubFor(
                post(urlPathEqualTo("/v1/ins-contracts"))
                        .inScenario("Token Refresh Scenario")
                        .whenScenarioStateIs(STATE_AFTER_401)
                        .willReturn(
                                aResponse()
                                        .withStatus(201)
                                        .withHeader("Content-Type", "application/json")
                                        .withBody("{}")));
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        ContractCreateInputVariables variables = createValidVariables();

        FinalisationDataOutputVariables result =
                assertDoesNotThrow(
                        () -> finalisationWorker.createContract(BUSINESS_KEY, variables, job));

        assertNotNull(result);
        assertEquals(ResponseCode.SUCCESS, result.result());
        assertNull(result.errorMessage());

        verify(2, postRequestedFor(urlPathEqualTo("/v1/ins-contracts")));
    }

    private ContractCreateInputVariables createValidVariables() {
        return new ContractCreateInputVariables(
                3,
                "7707083893",
                "romashka@rambler.ru",
                "Z6922/888/ABR14880/10",
                OffsetDateTime.of(2027, 7, 1, 0, 0, 0, 0, ZoneOffset.UTC),
                OffsetDateTime.of(2028, 7, 1, 0, 0, 0, 0, ZoneOffset.UTC),
                150000.93,
                50000.55,
                OffsetDateTime.of(2027, 7, 1, 0, 0, 0, 0, ZoneOffset.UTC),
                "40802810000000000000",
                12,
                "payment_account",
                "http://contract.link",
                "http://policy.link",
                "http://agreement.link",
                createInsuranceObjectsNode(),
                "AAAX22",
                null,
                "+79001234567",
                "г. Пушкино ул. Колотушкина д. 14/88",
                "ASASAS",
                "SFA");
    }

    private List<InsuranceObjectDto> createInsuranceObjectsNode() {
        InsuranceObjectDto insuranceObject1 = new InsuranceObjectDto();

        insuranceObject1.setEmployeeFIO("Иванов Иван Иванович");
        insuranceObject1.setEmployeeEmail("ivanov.ii@example.com");
        insuranceObject1.setEmployeePhoneNumber("+7 (999) 123-45-67");
        insuranceObject1.setEmployeeBirthDate(LocalDate.of(1985, 5, 15));
        insuranceObject1.setPaymentAccount("40817810099910004312");
        insuranceObject1.setCadastralNumber("77:01:0001045:32");
        insuranceObject1.setArea(45.5);
        insuranceObject1.setRealEstateAddress("г. Москва, ул. Тверская, д. 15, кв. 78");
        insuranceObject1.setRealEstateType(RealEstateTypeDto.COMMERCIAL);

        InsuranceObjectDto insuranceObject2 = new InsuranceObjectDto();

        insuranceObject2.setEmployeeFIO("Иванов Иван Иванович");
        insuranceObject2.setEmployeeEmail("ivanov.ii@example.com");
        insuranceObject2.setEmployeePhoneNumber("+7 (999) 123-45-67");
        insuranceObject2.setEmployeeBirthDate(LocalDate.of(1985, 5, 15));
        insuranceObject2.setPaymentAccount("40817810099910004312");
        insuranceObject2.setCadastralNumber("77:01:0001045:32");
        insuranceObject2.setArea(45.5);
        insuranceObject2.setRealEstateAddress("г. Москва, ул. Тверская, д. 15, кв. 78");
        insuranceObject2.setRealEstateType(RealEstateTypeDto.RESIDENTIAL);

        return List.of(insuranceObject1, insuranceObject2);
    }
}
