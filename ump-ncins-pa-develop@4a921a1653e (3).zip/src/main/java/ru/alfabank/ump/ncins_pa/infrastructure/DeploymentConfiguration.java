package ru.alfabank.ump.ncins_pa.infrastructure;

import io.camunda.zeebe.spring.client.annotation.Deployment;
import org.springframework.context.annotation.Configuration;

@Configuration
@Deployment(
        resources = {
            "classpath:bpmn/ump-finalisation-ncins-pa.bpmn",
            "classpath:bpmn/ump-payment-ncins-pa.bpmn",
            "classpath:bpmn/ump-prepare-documents-ncins-pa.bpmn",
            "classpath:bpmn/ump-signing-documents-ncins-pa.bpmn",
            "classpath:bpmn/ump-delete-documents-ncins-pa.bpmn"
        })
public class DeploymentConfiguration {}
