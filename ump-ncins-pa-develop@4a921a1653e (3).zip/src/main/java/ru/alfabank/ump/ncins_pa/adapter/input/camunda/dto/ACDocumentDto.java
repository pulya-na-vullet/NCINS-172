package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import java.util.UUID;

public record ACDocumentDto(String type, UUID acId) {}
