package ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator;

import static java.lang.String.format;
import static java.util.Objects.requireNonNull;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.VALIDATION_REQUIRED_MESSAGE;

import java.util.UUID;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.PrepareDataForPrintFormInputVariables;

public final class PrepareDataForPrintFormValidator {

    public static void validate(
            PrepareDataForPrintFormInputVariables prepareDataForPrintFormInputVariables,
            String processInstanceKey,
            UUID businessKey) {
        requireNonNull(
                prepareDataForPrintFormInputVariables,
                format(
                        VALIDATION_REQUIRED_MESSAGE,
                        processInstanceKey,
                        businessKey,
                        "prepareDataForPrintFormInputVariables"));
        requireNonNull(
                prepareDataForPrintFormInputVariables.programId(),
                format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "programId"));
        if (isBlank(prepareDataForPrintFormInputVariables.fullName())) {
            throw new RuntimeException(
                    format(
                            VALIDATION_REQUIRED_MESSAGE,
                            processInstanceKey,
                            businessKey,
                            "fullName"));
        }
        if (isBlank(prepareDataForPrintFormInputVariables.inn())) {
            throw new RuntimeException(
                    format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "inn"));
        }
        if (isBlank(prepareDataForPrintFormInputVariables.email())) {
            throw new RuntimeException(
                    format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "email"));
        }
        if (isBlank(prepareDataForPrintFormInputVariables.contractNumber())) {
            throw new RuntimeException(
                    format(
                            VALIDATION_REQUIRED_MESSAGE,
                            processInstanceKey,
                            businessKey,
                            "contractNumber"));
        }
        requireNonNull(
                prepareDataForPrintFormInputVariables.beginDate(),
                format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "beginDate"));
        requireNonNull(
                prepareDataForPrintFormInputVariables.endDate(),
                format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "endDate"));
        if (isBlank(prepareDataForPrintFormInputVariables.currentDate())) {
            throw new RuntimeException(
                    format(
                            VALIDATION_REQUIRED_MESSAGE,
                            processInstanceKey,
                            businessKey,
                            "currentDate"));
        }
        requireNonNull(
                prepareDataForPrintFormInputVariables.insuranceSum(),
                format(
                        VALIDATION_REQUIRED_MESSAGE,
                        processInstanceKey,
                        businessKey,
                        "insuranceSum"));
        requireNonNull(
                prepareDataForPrintFormInputVariables.insurancePremium(),
                format(
                        VALIDATION_REQUIRED_MESSAGE,
                        processInstanceKey,
                        businessKey,
                        "insurancePremium"));
        if (isBlank(prepareDataForPrintFormInputVariables.paymentAccount())) {
            throw new RuntimeException(
                    format(
                            VALIDATION_REQUIRED_MESSAGE,
                            processInstanceKey,
                            businessKey,
                            "paymentAccount"));
        }
    }
}
