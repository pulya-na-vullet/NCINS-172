package ru.alfabank.ump.ncins_pa.usecase.service;

import java.util.Map;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;
import ru.alfabank.ump.ncins_pa.usecase.port.input.PaymentInputPort;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService implements PaymentInputPort {

    @Override
    public SetHoldDto setHold(Map<String, Object> variables) {
        return new SetHoldDto();
    }

    @Override
    public CreatePaymentDto createPayment(Map<String, Object> variables) {
        return new CreatePaymentDto();
    }

    // TODO Временная заглушка
    @Data
    public static class SetHoldDto {
        private ResponseCode code = ResponseCode.SUCCESS;
    }

    // TODO Временная заглушка
    @Data
    public static class CreatePaymentDto {
        private ResponseCode code = ResponseCode.SUCCESS;
    }
}
