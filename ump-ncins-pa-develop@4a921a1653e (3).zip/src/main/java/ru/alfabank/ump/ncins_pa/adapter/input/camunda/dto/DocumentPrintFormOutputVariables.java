package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

public record DocumentPrintFormOutputVariables(
        String documentType, String reportData, Boolean isWriteInEa) {}
