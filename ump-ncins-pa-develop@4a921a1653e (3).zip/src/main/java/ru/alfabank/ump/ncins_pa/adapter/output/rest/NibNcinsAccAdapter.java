package ru.alfabank.ump.ncins_pa.adapter.output.rest;

import java.util.Collections;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.ContractRequestDto;
import ru.alfabank.ump.ncins_pa.adapter.output.rest.client.NibNcinsAccClient;
import ru.alfabank.ump.ncins_pa.adapter.output.rest.config.NibNcinsAccProperties;
import ru.alfabank.ump.ncins_pa.usecase.port.output.NibNcinsAccOutputPort;

@Slf4j
@Component
@RequiredArgsConstructor
public class NibNcinsAccAdapter implements NibNcinsAccOutputPort {

    private final NibNcinsAccClient nibNcinsAccClient;
    private final NibNcinsAccProperties nibNcinsAccProperties;

    @Override
    public void createContract(ContractRequestDto contractRequestDto) {
        String uPinOwner = contractRequestDto.getOwner().getOwnerId();

        nibNcinsAccClient.createContract(
                uPinOwner,
                Collections.singletonList(uPinOwner),
                nibNcinsAccProperties.getClientType(),
                nibNcinsAccProperties.getChannelId(),
                contractRequestDto,
                null,
                nibNcinsAccProperties.getProjectId());
    }
}
