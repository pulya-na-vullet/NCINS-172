package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;

public record ProductDataUpdateOutputVariables(ResponseCode getProcessParams) {}
