package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

public record DocumentDto(String documentLink) {}
