package ru.alfabank.ump.ncins_pa.infrastructure;

import feign.Response;
import feign.codec.ErrorDecoder;
import ru.alfabank.ump.ncins_pa.infrastructure.utils.FeignResponseUtils;

public class FeignErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {
        return FeignResponseUtils.toException(methodKey, response);
    }
}
