package ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums;

public enum ResponseCode {
    SUCCESS,
    ERROR
}
