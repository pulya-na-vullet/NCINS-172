package ru.alfabank.ump.ncins_pa.usecase.port.output;

import java.util.UUID;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductDto;

public interface ProductsOutputPort {

    ProductDto putProduct(
            UUID productId, ProductCommonParamDto productCommonParamDto, String processInstanceKey);
}
