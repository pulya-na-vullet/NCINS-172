package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import java.util.Map;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentResponseOutputVariables;
import ru.alfabank.ump.ncins_pa.usecase.port.input.DeleteDocumentsInputPort;

/**
 * Worker для обработки задачи удаления документов из АС 1.0. Вызывается для каждого документа в
 * коллекции documents.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DeleteDocumentsWorker {

    private static final String START_LOG =
            "[processInstanceKey={}, businessKey={}] Начало удаления документа: {}";
    private static final String END_LOG =
            "[processInstanceKey={}, businessKey={}] Документ успешно удалён: {}";
    private static final String ERROR_LOG =
            "[processInstanceKey={}, businessKey={}] Ошибка удаления документа: {}";

    private final DeleteDocumentsInputPort deleteDocumentsInputPort;

    /**
     * Обрабатывает задачу удаления одного документа.
     *
     * @param document текущий документ из коллекции documents
     * @return результат удаления документа для записи в acDocuments
     */
    @JobWorker(type = "ump-delete-documents-ncins-pa.delete-documents")
    public DocumentResponseOutputVariables deleteDocument(
            @Variable UUID businessKey,
            @Variable("document") DocumentDto document,
            final ActivatedJob job) {
        String processInstanceKey = String.valueOf(job.getProcessInstanceKey());
        log.info(START_LOG, processInstanceKey, businessKey, document);
        try {
            var result = deleteDocumentsInputPort.deleteDocument(document);
            log.info(END_LOG, processInstanceKey, businessKey, document);
            return new DocumentResponseOutputVariables(result);
        } catch (Exception e) {
            log.error(ERROR_LOG, processInstanceKey, businessKey, document, e);
            return new DocumentResponseOutputVariables(Map.of("status", "2"));
        }
    }
}
