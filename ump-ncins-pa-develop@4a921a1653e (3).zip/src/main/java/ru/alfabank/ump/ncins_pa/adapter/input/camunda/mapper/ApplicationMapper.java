package ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper;

import static ru.alfabank.ump.ncins_pa.adapter.utils.DateTimeUtils.getCurrentDateStartDayWithDots;

import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import org.jetbrains.annotations.NotNull;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.InsuranceObjectDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ApplicationDataOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ApplicationProcessType;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;
import ru.alfabank.ump.ncins_pa.domain.exception.client.ApplicationFacadeException;
import ump.applicationfacade.api.dto.ApplicationResponseDto;
import ump.applicationfacade.api.dto.ChannelDto;
import ump.applicationfacade.api.dto.ContactDto;
import ump.applicationfacade.api.dto.ContactTypeDto;
import ump.applicationfacade.api.dto.ParticipantDto;
import ump.applicationfacade.api.dto.ProductDto;
import ump.applicationfacade.api.dto.ProductNonCreditInsuranceDto;
import ump.applicationfacade.api.dto.ProductNonCreditInsuranceInsuranceObjectsInnerDto;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        uses = {InsuranceObjectMapper.class})
public interface ApplicationMapper {

    @Mapping(target = "productProperties", ignore = true)
    ump.products.api.dto.ProductDto toProductDto(ProductDto productDto);

    ump.products.api.dto.ProductNonCreditInsuranceDto toProductNonCreditInsuranceDto(
            ProductNonCreditInsuranceDto productNonCreditInsuranceDto);

    default ApplicationDataOutputVariables mapToApplicationData(
            ApplicationResponseDto dto,
            String processInstanceKey,
            ApplicationProcessType processType) {

        return switch (processType) {
            case FINALISATION -> fillFinalisationFields(dto);
            case PAYMENT -> fillPaymentFields(dto);
            case PREPARE_DOCUMENTS -> fillPrepareDocumentsFields(dto, processInstanceKey);
            case SIGNING -> fillSigningFields(dto, processInstanceKey);
            case DELETE_DOCS -> fillDeleteFields(dto);
        };
    }

    private ApplicationDataOutputVariables fillFinalisationFields(ApplicationResponseDto dto) {
        ParticipantDto participant = dto.getParticipants().getFirst();
        String phoneNumber = getParticipantPhoneNumber(dto, participant);
        String fullAddress = getParticipantFullAddress(participant);
        String email = getParticipantEmail(dto, participant);
        ProductNonCreditInsuranceDto productProperties =
                (ProductNonCreditInsuranceDto) dto.getProducts().getFirst().getProductProperties();
        ChannelDto channelDto = dto.getChannels().getFirst();
        String sellerChannel = dto.getExternalApplicationIds().getFirst().getSystemCode();

        return ApplicationDataOutputVariables.builder()
                .getProcessParams(ResponseCode.SUCCESS)
                .programId(productProperties.getProgramId())
                .inn(participant.getInn())
                .email(email)
                .contractNumber(productProperties.getContractNumber())
                .beginDate(productProperties.getBeginDate())
                .endDate(productProperties.getEndDate())
                .insuranceSum(productProperties.getInsuranceSum())
                .insurancePremium(productProperties.getInsurancePremium())
                .signDate(productProperties.getSignDate())
                .debitAccount(productProperties.getDebitAccount())
                .duration(productProperties.getDuration())
                .paymentType(productProperties.getPaymentType())
                .contractLink(productProperties.getContractLink())
                .policyLink(productProperties.getPolicyLink())
                .agreementLink(productProperties.getAgreementLink())
                .insuranceObjects(mapInsuranceObjects(productProperties.getInsuranceObjects()))
                .ownerId(participant.getPin())
                .ogrn(participant.getOgrn())
                .phoneNumber(phoneNumber)
                .legalAddress(fullAddress)
                .sellerId(channelDto.getUserInfo().getLogin())
                .sellerChannel(sellerChannel)
                .build();
    }

    private ApplicationDataOutputVariables fillPaymentFields(ApplicationResponseDto dto) {
        var participant = dto.getParticipants().getFirst();
        var productProperties =
                (ProductNonCreditInsuranceDto) dto.getProducts().getFirst().getProductProperties();
        return ApplicationDataOutputVariables.builder()
                .getProcessParams(ResponseCode.SUCCESS)
                .fullName(participant.getFullName())
                .productId(dto.getProducts().getFirst().getId())
                .inn(participant.getInn())
                .contractNumber(productProperties.getContractNumber())
                .insurancePremium(productProperties.getInsurancePremium())
                .debitAccount(productProperties.getDebitAccount())
                .build();
    }

    private ApplicationDataOutputVariables fillPrepareDocumentsFields(
            ApplicationResponseDto dto, String processInstanceKey) {
        ProductDto product = dto.getProducts().getFirst();
        ParticipantDto participant = dto.getParticipants().getFirst();
        ProductNonCreditInsuranceDto productProperties =
                (ProductNonCreditInsuranceDto) dto.getProducts().getFirst().getProductProperties();
        ProductNonCreditInsuranceInsuranceObjectsInnerDto insuranceObject =
                productProperties.getInsuranceObjects().getFirst();
        ump.products.api.dto.ProductDto productInfo = toProductDto(dto.getProducts().getFirst());
        ump.products.api.dto.ProductNonCreditInsuranceDto productNonCreditInsuranceDto =
                toProductNonCreditInsuranceDto(productProperties);
        productInfo.setProductProperties(productNonCreditInsuranceDto);
        return ApplicationDataOutputVariables.builder()
                .getProcessParams(ResponseCode.SUCCESS)
                .processInstanceKey(processInstanceKey)
                .productId(product.getId())
                .fullName(participant.getFullName())
                .inn(participant.getInn())
                .email(getParticipantEmail(dto, participant))
                .contractNumber(productProperties.getContractNumber())
                .beginDate(productProperties.getBeginDate())
                .endDate(productProperties.getEndDate())
                .currentDate(getCurrentDateStartDayWithDots())
                .insuranceSum(productProperties.getInsuranceSum())
                .insurancePremium(productProperties.getInsurancePremium())
                .paymentAccount(insuranceObject.getPaymentAccount())
                .productInfo(productInfo)
                .build();
    }

    private ApplicationDataOutputVariables fillSigningFields(
            ApplicationResponseDto dto, String processInstanceKey) {
        return ApplicationDataOutputVariables.builder()
                .getProcessParams(ResponseCode.SUCCESS)
                .processInstanceKey(processInstanceKey)
                .build();
    }

    private ApplicationDataOutputVariables fillDeleteFields(ApplicationResponseDto dto) {
        ProductNonCreditInsuranceDto productProperties =
                (ProductNonCreditInsuranceDto) dto.getProducts().getFirst().getProductProperties();

        return ApplicationDataOutputVariables.builder()
                .documents(getDocumentDtoList(productProperties))
                .build();
    }

    @NotNull
    private static List<DocumentDto> getDocumentDtoList(
            ProductNonCreditInsuranceDto productProperties) {
        return Stream.of(
                        productProperties.getContractLink(),
                        productProperties.getPolicyLink(),
                        productProperties.getAgreementLink())
                .filter(Objects::nonNull)
                .map(DocumentDto::new)
                .toList();
    }

    @NotNull
    private static String getParticipantFullAddress(ParticipantDto participant) {
        return participant.getAddresses().getFirst().getAddress().getFullAddress();
    }

    @NotNull
    private static String getParticipantContact(
            ApplicationResponseDto dto, ParticipantDto participant, ContactTypeDto contactType) {
        return participant.getContacts().stream()
                .filter(c -> contactType.equals(c.getType()))
                .map(ContactDto::getValue)
                .findFirst()
                .orElseThrow(
                        () ->
                                new ApplicationFacadeException(
                                        String.format(
                                                "Не удалось получить %s клиента для заявки businessKey: %s",
                                                contactType.getValue(), dto.getId())));
    }

    @NotNull
    private static String getParticipantEmail(
            ApplicationResponseDto dto, ParticipantDto participant) {
        return getParticipantContact(dto, participant, ContactTypeDto.EMAIL);
    }

    @NotNull
    private static String getParticipantPhoneNumber(
            ApplicationResponseDto dto, ParticipantDto participant) {
        return getParticipantContact(dto, participant, ContactTypeDto.PHONE);
    }

    List<InsuranceObjectDto> mapInsuranceObjects(
            List<ProductNonCreditInsuranceInsuranceObjectsInnerDto> source);
}
