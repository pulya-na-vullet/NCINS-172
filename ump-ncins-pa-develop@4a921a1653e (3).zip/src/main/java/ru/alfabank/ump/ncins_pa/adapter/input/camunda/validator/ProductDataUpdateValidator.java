package ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator;

import static java.lang.String.format;
import static java.util.Objects.requireNonNull;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.VALIDATION_REQUIRED_MESSAGE;

import java.util.UUID;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductDataUpdateInputVariables;

public final class ProductDataUpdateValidator {

    public static void validate(
            ProductDataUpdateInputVariables productDataUpdateInputVariables,
            String processInstanceKey,
            UUID businessKey) {
        requireNonNull(
                productDataUpdateInputVariables,
                format(
                        VALIDATION_REQUIRED_MESSAGE,
                        processInstanceKey,
                        businessKey,
                        "productDataUpdateInputVariables"));
        requireNonNull(
                productDataUpdateInputVariables.productId(),
                format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "productId"));
        requireNonNull(
                productDataUpdateInputVariables.acDocuments(),
                format(
                        VALIDATION_REQUIRED_MESSAGE,
                        processInstanceKey,
                        businessKey,
                        "acDocuments"));
        requireNonNull(
                productDataUpdateInputVariables.acDocuments().getFirst().acId(),
                format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "acId"));
        if (isBlank(productDataUpdateInputVariables.acDocuments().getFirst().type())) {
            throw new RuntimeException(
                    format(VALIDATION_REQUIRED_MESSAGE, processInstanceKey, businessKey, "type"));
        }
        requireNonNull(
                productDataUpdateInputVariables.productInfo(),
                format(
                        VALIDATION_REQUIRED_MESSAGE,
                        processInstanceKey,
                        businessKey,
                        "productInfo"));
    }
}
