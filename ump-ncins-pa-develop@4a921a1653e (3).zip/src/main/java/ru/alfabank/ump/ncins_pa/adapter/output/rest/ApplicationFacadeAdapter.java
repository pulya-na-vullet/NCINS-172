package ru.alfabank.ump.ncins_pa.adapter.output.rest;

import static ump.applicationfacade.api.dto.ApplicationEntitiesDto.PARTICIPANT;
import static ump.applicationfacade.api.dto.ApplicationEntitiesDto.PRODUCT;

import io.github.resilience4j.retry.annotation.Retry;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.alfabank.ump.ncins_pa.domain.exception.client.ApplicationFacadeException;
import ru.alfabank.ump.ncins_pa.domain.util.ConstUtils;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ApplicationFacadeOutputPort;
import ump.applicationfacade.api.ApplicationFacadeApiClient;
import ump.applicationfacade.api.dto.ApplicationResponseDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApplicationFacadeAdapter implements ApplicationFacadeOutputPort {
    private final ApplicationFacadeApiClient applicationFacadeApiClient;

    @Retry(name = ConstUtils.RETRY_DEFAULT_NAME, fallbackMethod = "getApplicationFallback")
    @Override
    public ApplicationResponseDto getApplication(UUID businessKey) {
        return applicationFacadeApiClient.getApplicationById(
                businessKey, List.of(PARTICIPANT, PRODUCT), null);
    }

    private ApplicationResponseDto getApplicationFallback(UUID businessKey, Exception ex) {
        throw new ApplicationFacadeException(
                "Не удалось получить данные заявки для businessKey: " + businessKey, ex);
    }
}
