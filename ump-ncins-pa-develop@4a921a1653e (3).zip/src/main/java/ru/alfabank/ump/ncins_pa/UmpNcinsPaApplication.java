package ru.alfabank.ump.ncins_pa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UmpNcinsPaApplication {
    public static void main(String[] args) {
        SpringApplication.run(UmpNcinsPaApplication.class, args);
    }
}
