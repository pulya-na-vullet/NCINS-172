package ru.alfabank.ump.ncins_pa.adapter.utils;

import static java.time.Instant.now;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public final class DateTimeUtils {

    private static final String UTC = "UTC";

    private static final DateTimeFormatter DATE_START_DAY_WITH_DOTS_FORMATTER =
            DateTimeFormatter.ofPattern("dd.MM.yyyy").withZone(ZoneId.of(UTC));

    private static final DateTimeFormatter DATE_START_YEAR_WITH_DASH_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd").withZone(ZoneId.of(UTC));

    public static String getCurrentDateStartDayWithDots() {
        return DATE_START_DAY_WITH_DOTS_FORMATTER.format(now());
    }

    public static String getDateStartYearWithDash(OffsetDateTime offsetDateTime) {
        return DATE_START_YEAR_WITH_DASH_FORMATTER.format(offsetDateTime);
    }

    public static String formatOffsetDateTime(OffsetDateTime dateTime) {
        return getDateStartYearWithDash(dateTime);
    }
}
