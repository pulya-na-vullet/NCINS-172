package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import java.time.OffsetDateTime;

public record PrepareDataForPrintFormInputVariables(
        Integer programId,
        String fullName,
        String inn,
        String email,
        String contractNumber,
        OffsetDateTime beginDate,
        OffsetDateTime endDate,
        String currentDate,
        Double insuranceSum,
        Double insurancePremium,
        String paymentAccount) {}
