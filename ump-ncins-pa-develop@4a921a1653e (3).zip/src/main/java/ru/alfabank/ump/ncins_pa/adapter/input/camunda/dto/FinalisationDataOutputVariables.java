package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;

public record FinalisationDataOutputVariables(ResponseCode result, String errorMessage) {

    public static FinalisationDataOutputVariables success() {
        return new FinalisationDataOutputVariables(ResponseCode.SUCCESS, null);
    }

    public static FinalisationDataOutputVariables error(String errorMessage) {
        return new FinalisationDataOutputVariables(ResponseCode.ERROR, errorMessage);
    }
}
