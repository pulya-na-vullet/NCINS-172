package ru.alfabank.ump.ncins_pa.domain.util;

public final class ConstUtils {
    public static final String RETRY_DEFAULT_NAME = "default";
}
