package ru.alfabank.ump.ncins_pa.usecase.service;

import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentDto;
import ru.alfabank.ump.ncins_pa.usecase.port.input.DeleteDocumentsInputPort;

@Slf4j
@Service
@RequiredArgsConstructor
public class DeleteDocumentsService implements DeleteDocumentsInputPort {

    @Override
    public Map<String, Object> deleteDocument(DocumentDto document) {
        log.info("Удаление документа: {}", document);

        // TODO: Вызов API АС 1.0 для удаления документа
        return Map.of("status", "1");
    }
}
