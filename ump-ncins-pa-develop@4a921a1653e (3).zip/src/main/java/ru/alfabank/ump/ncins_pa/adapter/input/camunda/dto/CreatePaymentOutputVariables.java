package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;

@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CreatePaymentOutputVariables(ResponseCode code, String message) {
    public static CreatePaymentOutputVariables error(String message) {
        return CreatePaymentOutputVariables.builder()
                .code(ResponseCode.ERROR)
                .message(message)
                .build();
    }
}
