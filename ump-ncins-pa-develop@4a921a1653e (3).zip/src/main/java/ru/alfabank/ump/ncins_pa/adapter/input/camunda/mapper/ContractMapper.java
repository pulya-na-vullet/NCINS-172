package ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.ContractRequestDto;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.PaymentTypeDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ContractCreateInputVariables;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        uses = {InsuranceObjectMapper.class})
public interface ContractMapper {

    @Mapping(target = "beginDate", source = "beginDate")
    @Mapping(target = "endDate", source = "endDate")
    @Mapping(target = "signDate", source = "signDate")
    @Mapping(target = "owner.inn", source = "inn")
    @Mapping(target = "owner.phoneNumber", source = "phoneNumber")
    @Mapping(target = "owner.legalAddress", source = "legalAddress")
    @Mapping(target = "owner.ogrn", source = "ogrn")
    @Mapping(target = "owner.ownerId", source = "ownerId")
    @Mapping(target = "owner.email", source = "email")
    @Mapping(
            target = "paymentType",
            source = "paymentType",
            qualifiedByName = "stringToPaymentType")
    ContractRequestDto mapToContractDto(ContractCreateInputVariables variables);

    @Named("stringToPaymentType")
    default PaymentTypeDto stringToPaymentType(String value) {
        return PaymentTypeDto.fromValue(value);
    }
}
