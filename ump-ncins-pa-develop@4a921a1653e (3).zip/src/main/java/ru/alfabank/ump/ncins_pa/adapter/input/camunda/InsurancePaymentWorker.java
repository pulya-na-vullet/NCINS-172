package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import java.util.Map;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.CreatePaymentOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.SetHoldOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.CreatePaymentMapper;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.SetHoldMapper;
import ru.alfabank.ump.ncins_pa.usecase.port.input.PaymentInputPort;

@Slf4j
@Component
@RequiredArgsConstructor
public class InsurancePaymentWorker {

    private static final String START_SET_HOLD_LOG =
            "[processInstanceKey={}, businessKey={}] Начало процесса установить Hold по счету: {}";
    private static final String END_SET_HOLD_LOG =
            "[processInstanceKey={}, businessKey={}] Процесс установить Hold по счету завершён: {}";
    private static final String ERROR_SET_HOLD_LOG =
            "[processInstanceKey={}, businessKey={}] Процесс установить Hold по счету завершился ошибкой: {}";

    private static final String START_CREATE_PAYMENT_LOG =
            "[processInstanceKey={}, businessKey={}] Начало создания платежного поручения: {}";
    private static final String END_CREATE_PAYMENT_LOG =
            "[processInstanceKey={}, businessKey={}] Платежное поручение создано: {}";
    private static final String ERROR_CREATE_PAYMENT_LOG =
            "[processInstanceKey={}, businessKey={}] Процесс создания платежного поручения завершился ошибкой: {}";

    private final PaymentInputPort paymentInputPort;
    private final SetHoldMapper setHoldMapper;
    private final CreatePaymentMapper createPaymentMapper;

    /* Установить Hold по счету */
    @JobWorker(type = "ump-payment-ncins-pa.set-hold")
    public SetHoldOutputVariables setHold(
            @Variable UUID businessKey,
            @VariablesAsType Map<String, Object> variables,
            final ActivatedJob job) {
        String processInstanceKey = String.valueOf(job.getProcessInstanceKey());
        log.info(START_SET_HOLD_LOG, processInstanceKey, businessKey, variables);
        try {
            SetHoldOutputVariables result =
                    setHoldMapper.mapToSetHold(paymentInputPort.setHold(variables));
            log.info(END_SET_HOLD_LOG, processInstanceKey, businessKey, variables);
            return result;
        } catch (Exception e) {
            log.error(ERROR_SET_HOLD_LOG, processInstanceKey, businessKey, variables, e);
            return SetHoldOutputVariables.error(e.getMessage());
        }
    }

    /* Создать платежное поручение */
    @JobWorker(type = "ump-payment-ncins-pa.create-payment")
    public CreatePaymentOutputVariables createPayment(
            @Variable UUID businessKey,
            @VariablesAsType Map<String, Object> variables,
            final ActivatedJob job) {
        String processInstanceKey = String.valueOf(job.getProcessInstanceKey());
        log.info(START_CREATE_PAYMENT_LOG, processInstanceKey, businessKey, variables);
        try {
            CreatePaymentOutputVariables result =
                    createPaymentMapper.mapToCreatePayment(
                            paymentInputPort.createPayment(variables));
            log.info(END_CREATE_PAYMENT_LOG, processInstanceKey, businessKey, variables);
            return result;
        } catch (Exception e) {
            log.error(ERROR_CREATE_PAYMENT_LOG, processInstanceKey, businessKey, variables, e);
            return CreatePaymentOutputVariables.error(e.getMessage());
        }
    }
}
