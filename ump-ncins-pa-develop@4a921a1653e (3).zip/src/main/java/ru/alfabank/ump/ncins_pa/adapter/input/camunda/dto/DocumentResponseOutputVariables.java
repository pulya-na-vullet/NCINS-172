package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

public record DocumentResponseOutputVariables(Object documentResponse) {}
