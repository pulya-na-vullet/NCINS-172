package ru.alfabank.ump.ncins_pa.domain;

public record PrepareDocumentsResult(boolean result, String message) {}
