package ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums;

public enum ApplicationProcessType {
    FINALISATION,
    PAYMENT,
    PREPARE_DOCUMENTS,
    SIGNING,
    DELETE_DOCS
}
