package ru.alfabank.ump.ncins_pa.infrastructure;

import feign.codec.ErrorDecoder;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.alfabank.ump.ncins_pa.adapter.output.rest.client.NibNcinsAccClient;
import ump.applicationfacade.api.ApplicationFacadeApiClient;
import ump.products.api.ProductsApiClient;

@Configuration
@EnableFeignClients(
        clients = {
            ApplicationFacadeApiClient.class,
            NibNcinsAccClient.class,
            ProductsApiClient.class
        })
public class FeignConfiguration {

    @Bean
    public ErrorDecoder errorDecoder() {
        return new FeignErrorDecoder();
    }
}
