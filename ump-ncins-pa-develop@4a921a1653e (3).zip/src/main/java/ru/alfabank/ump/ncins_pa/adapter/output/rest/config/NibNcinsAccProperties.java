package ru.alfabank.ump.ncins_pa.adapter.output.rest.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "integration.nib.corp-ncins-acc-api")
@Data
public class NibNcinsAccProperties {

    private String xpinConst;
    private String clientType;
    private String channelId;
    private String projectId;
}
