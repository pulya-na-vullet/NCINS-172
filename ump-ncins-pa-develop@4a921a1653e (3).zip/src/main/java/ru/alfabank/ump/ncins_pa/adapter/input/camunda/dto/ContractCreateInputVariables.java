package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import java.time.OffsetDateTime;
import java.util.List;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.InsuranceObjectDto;

public record ContractCreateInputVariables(
        int programId,
        String inn,
        String email,
        String contractNumber,
        OffsetDateTime beginDate,
        OffsetDateTime endDate,
        double insuranceSum,
        double insurancePremium,
        OffsetDateTime signDate,
        String debitAccount,
        int duration,
        String paymentType,
        String contractLink,
        String policyLink,
        String agreementLink,
        List<InsuranceObjectDto> insuranceObjects,
        String ownerId,
        String ogrn,
        String phoneNumber,
        String legalAddress,
        String sellerId,
        String sellerChannel) {}
