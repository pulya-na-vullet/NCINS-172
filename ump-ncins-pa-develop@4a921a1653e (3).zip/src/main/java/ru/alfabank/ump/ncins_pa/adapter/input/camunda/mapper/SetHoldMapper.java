package ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.SetHoldOutputVariables;
import ru.alfabank.ump.ncins_pa.usecase.service.PaymentService;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface SetHoldMapper {

    SetHoldOutputVariables mapToSetHold(PaymentService.SetHoldDto dto);
}
