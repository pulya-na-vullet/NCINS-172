package ru.alfabank.ump.ncins_pa.adapter.utils;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public final class DecimalUtils {

    public static String formatDouble(Double value) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setDecimalSeparator('.');
        DecimalFormat df = new DecimalFormat("#0.00");
        df.setGroupingUsed(false);
        df.setDecimalFormatSymbols(symbols);
        return df.format(value);
    }
}
