package ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductDto;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface ProductsMapper {

    ProductCommonParamDto toProductCommonParamDto(ProductDto productInfo);
}
