package ru.alfabank.ump.ncins_pa.adapter.output.rest.config;

import feign.Response;
import org.springframework.http.HttpStatus;
import ru.alfabank.auth.client.FeignAuthErrorDecoder;
import ru.alfabank.ump.ncins_pa.infrastructure.utils.FeignResponseUtils;

public class NibNcinsAccErrorDecoder extends FeignAuthErrorDecoder {

    @Override
    public Exception decode(String s, Response response) {
        if (response.status() == HttpStatus.UNAUTHORIZED.value()) {
            return super.decode(s, response);
        }
        return FeignResponseUtils.toException(s, response);
    }
}
