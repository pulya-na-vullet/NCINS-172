package ru.alfabank.ump.ncins_pa.domain.exception.client;

public class ApplicationFacadeException extends RuntimeException {
    public ApplicationFacadeException(String message) {
        super(message);
    }

    public ApplicationFacadeException(String message, Throwable cause) {
        super(message, cause);
    }
}
