package ru.alfabank.ump.ncins_pa.infrastructure.utils;

import feign.Response;
import feign.codec.ErrorDecoder.Default;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import ru.alfabank.ump.ncins_pa.domain.exception.client.NotRetryExternalClientException;
import ru.alfabank.ump.ncins_pa.domain.exception.client.RetryExternalClientException;

@Slf4j
@UtilityClass
public class FeignResponseUtils {

    public static Exception toException(String methodKey, Response response) {
        String body = getBody(response);
        HttpStatus status = HttpStatus.valueOf(response.status());

        if (status.is4xxClientError()) {
            return new NotRetryExternalClientException(body);
        }

        if (status.is5xxServerError()) {
            return new RetryExternalClientException(body);
        }

        return new Default().decode(methodKey, response);
    }

    private static String getBody(Response response) {
        if (Objects.isNull(response) || Objects.isNull(response.body())) {
            return null;
        }
        try {
            return new String(
                    response.body().asInputStream().readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }
}
