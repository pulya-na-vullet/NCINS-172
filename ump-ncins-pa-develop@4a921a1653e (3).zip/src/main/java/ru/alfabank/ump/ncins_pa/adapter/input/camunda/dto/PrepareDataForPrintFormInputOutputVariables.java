package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import java.util.List;
import java.util.UUID;
import lombok.Builder;

@Builder
public record PrepareDataForPrintFormInputOutputVariables(
        UUID serviceId,
        String serviceCode,
        String productCode,
        List<DocumentPrintFormOutputVariables> documents) {}
