package ru.alfabank.ump.ncins_pa.domain.exception.client;

public class NotRetryExternalClientException extends RuntimeException {

    public NotRetryExternalClientException(String message) {
        super(message);
    }
}
