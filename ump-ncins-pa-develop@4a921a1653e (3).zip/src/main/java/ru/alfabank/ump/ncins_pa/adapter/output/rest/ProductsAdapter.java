package ru.alfabank.ump.ncins_pa.adapter.output.rest;

import static ru.alfabank.ump.ncins_pa.domain.util.ConstUtils.RETRY_DEFAULT_NAME;

import io.github.resilience4j.retry.annotation.Retry;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ProductsOutputPort;
import ump.products.api.ProductsApiClient;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductsAdapter implements ProductsOutputPort {

    private final ProductsApiClient productsApiClient;

    @Retry(name = RETRY_DEFAULT_NAME)
    @Override
    public ProductDto putProduct(
            UUID productId,
            ProductCommonParamDto productCommonParamDto,
            String processInstanceKey) {
        return productsApiClient.putProduct(productId, productCommonParamDto);
    }
}
