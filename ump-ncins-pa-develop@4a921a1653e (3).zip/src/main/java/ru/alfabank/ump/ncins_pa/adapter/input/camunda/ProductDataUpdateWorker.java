package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static java.lang.String.valueOf;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.ERROR;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.SUCCESS;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ProductDataUpdateValidator.validate;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductDataUpdateInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductDataUpdateOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.ProductsMapper;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ProductsOutputPort;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductDto;
import ump.products.api.dto.ProductNonCreditInsuranceDto;

@Slf4j
@Component
@RequiredArgsConstructor
public class ProductDataUpdateWorker {

    private static final String START_LOG =
            "[processInstanceKey={}, businessKey={}] Начало обновления данных по продукту: {}";
    private static final String END_LOG =
            "[processInstanceKey={}, businessKey={}] Конец обновления данных по продукту: {}";
    private static final String PUT_PRODUCT_ERROR_MESSAGE =
            "[processInstanceKey={}, businessKey={}] Не удалось обновить данные по продукту: {}";

    private final ProductsOutputPort productsOutputPort;
    private final ProductsMapper productsMapper;

    /**
     * Обновляет данные по продукту.
     *
     * @param productDataUpdateInputVariables Входные данные
     * @param job информация о задаче Zeebe
     */
    @JobWorker(type = "update-product")
    public ProductDataUpdateOutputVariables productDataUpdate(
            @Variable UUID businessKey,
            @VariablesAsType ProductDataUpdateInputVariables productDataUpdateInputVariables,
            final ActivatedJob job) {
        String processInstanceKey = valueOf(job.getProcessInstanceKey());

        validate(productDataUpdateInputVariables, processInstanceKey, businessKey);

        log.info(START_LOG, processInstanceKey, businessKey, productDataUpdateInputVariables);

        ProductDto productInfo = productDataUpdateInputVariables.productInfo();
        ProductCommonParamDto productCommonParamDto =
                productsMapper.toProductCommonParamDto(productInfo);
        ProductNonCreditInsuranceDto productNonCreditInsuranceDto =
                (ProductNonCreditInsuranceDto) productCommonParamDto.getProductProperties();
        UUID acId = productDataUpdateInputVariables.acDocuments().getFirst().acId();
        productNonCreditInsuranceDto.setPolicyLink(acId.toString());

        try {
            ProductDto putProduct =
                    productsOutputPort.putProduct(
                            productDataUpdateInputVariables.productId(),
                            productCommonParamDto,
                            processInstanceKey);
            log.info(END_LOG, processInstanceKey, businessKey, putProduct);
        } catch (Exception ex) {
            log.error(
                    PUT_PRODUCT_ERROR_MESSAGE,
                    processInstanceKey,
                    businessKey,
                    productCommonParamDto,
                    ex);
            return new ProductDataUpdateOutputVariables(ERROR);
        }

        return new ProductDataUpdateOutputVariables(SUCCESS);
    }
}
