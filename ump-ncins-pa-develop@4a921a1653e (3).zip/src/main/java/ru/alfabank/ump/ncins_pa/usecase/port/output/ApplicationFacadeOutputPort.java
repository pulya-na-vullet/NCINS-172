package ru.alfabank.ump.ncins_pa.usecase.port.output;

import java.util.UUID;
import ump.applicationfacade.api.dto.ApplicationResponseDto;

public interface ApplicationFacadeOutputPort {

    ApplicationResponseDto getApplication(UUID businessKey);
}
