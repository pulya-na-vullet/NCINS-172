package ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.CreatePaymentOutputVariables;
import ru.alfabank.ump.ncins_pa.usecase.service.PaymentService;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface CreatePaymentMapper {

    CreatePaymentOutputVariables mapToCreatePayment(PaymentService.CreatePaymentDto dto);
}
