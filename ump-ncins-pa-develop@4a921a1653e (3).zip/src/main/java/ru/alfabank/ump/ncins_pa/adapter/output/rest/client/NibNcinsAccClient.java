package ru.alfabank.ump.ncins_pa.adapter.output.rest.client;

import io.github.resilience4j.retry.annotation.Retry;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseStatus;
import ru.alfabank.auth.client.FeignClientAuthConfiguration;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.ContractRequestDto;
import ru.alfabank.ump.ncins_pa.adapter.output.rest.config.NibNcinsAccErrorDecoder;
import ru.alfabank.ump.ncins_pa.domain.util.ConstUtils;

@FeignClient(
        name = "nibNcinsAccClient",
        url = "${integration.nib.corp-ncins-acc-api.url}",
        configuration = {FeignClientAuthConfiguration.class, NibNcinsAccErrorDecoder.class})
public interface NibNcinsAccClient {

    @Retry(name = ConstUtils.RETRY_DEFAULT_NAME)
    @PostMapping(
            value = "/v1/ins-contracts",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    void createContract(
            @RequestHeader("A-userId") String aUserId,
            @RequestHeader("A-customerId") List<String> aCustomerId,
            @RequestHeader("A-clientType") String aClientType,
            @RequestHeader("A-channelId") String aChannelId,
            @RequestBody ContractRequestDto contractRequestDto,
            @RequestHeader(value = "A-userIp", required = false) String aUserIp,
            @RequestHeader(value = "A-projectId", required = false) String aProjectId);
}
