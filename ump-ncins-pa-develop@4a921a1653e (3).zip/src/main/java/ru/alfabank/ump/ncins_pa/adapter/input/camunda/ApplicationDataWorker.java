package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ApplicationDataOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ApplicationProcessType;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.ApplicationMapper;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ApplicationFacadeOutputPort;

/** Worker для получения данных из мультизаявки. */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApplicationDataWorker {

    private static final String START_LOG =
            "[processInstanceKey={}, businessKey={}] Начало процесса {} получения данных из мультизаявки";
    private static final String END_LOG =
            "[processInstanceKey={}, businessKey={}] Конец процесса {} получения данных из мультизаявки: {}";
    private static final String ERROR_LOG =
            "[processInstanceKey={}, businessKey={}] Процесс {} получения данных завершился ошибкой из мультизаявки";

    private final ApplicationFacadeOutputPort applicationFacadeOutputPort;
    private final ApplicationMapper applicationMapper;

    /**
     * Обрабатывает задачу получения данных из мультизаявки.
     *
     * @param businessKey ID мультизаявки
     * @param processType Тип процесса в рамках которого идет получение данных
     * @param job информация о задаче Zeebe
     */
    @JobWorker(type = "get-application-data")
    public ApplicationDataOutputVariables getApplicationData(
            @Variable UUID businessKey, @Variable String processType, final ActivatedJob job) {
        String processInstanceKey = String.valueOf(job.getProcessInstanceKey());

        log.info(START_LOG, processInstanceKey, businessKey, processType);

        try {
            ApplicationDataOutputVariables result =
                    applicationMapper.mapToApplicationData(
                            applicationFacadeOutputPort.getApplication(businessKey),
                            processInstanceKey,
                            ApplicationProcessType.valueOf(processType));

            log.info(END_LOG, processInstanceKey, businessKey, processType, result);

            return result;
        } catch (Exception e) {
            log.error(ERROR_LOG, processInstanceKey, businessKey, processType, e);
            return ApplicationDataOutputVariables.error();
        }
    }
}
