package ru.alfabank.ump.ncins_pa.domain.exception.client;

public class RetryExternalClientException extends RuntimeException {

    public RetryExternalClientException(String message) {
        super(message);
    }
}
