package ru.alfabank.ump.ncins_pa.usecase.port.input;

import java.util.Map;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentDto;

/** Входной порт для процесса удаления документов. */
public interface DeleteDocumentsInputPort {

    /**
     * Удаляет один документ из АС 1.0.
     *
     * @param document данные документа для удаления
     * @return результат удаления (documentResponse)
     */
    Map<String, Object> deleteDocument(DocumentDto document);
}
