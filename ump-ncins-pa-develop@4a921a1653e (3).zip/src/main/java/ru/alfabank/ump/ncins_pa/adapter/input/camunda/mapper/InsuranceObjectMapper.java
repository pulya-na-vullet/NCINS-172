package ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper;

import static java.util.Objects.isNull;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.InsuranceObjectDto;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.RealEstateTypeDto;
import ump.applicationfacade.api.dto.ProductNonCreditInsuranceInsuranceObjectsInnerDto;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InsuranceObjectMapper {

    @Mapping(
            target = "realEstateType",
            source = "realEstateType",
            qualifiedByName = "stringToRealEstateTypeDto")
    InsuranceObjectDto mapToInsuranceObjectDto(
            ProductNonCreditInsuranceInsuranceObjectsInnerDto dto);

    @Named("stringToRealEstateTypeDto")
    default RealEstateTypeDto stringToRealEstateTypeDto(String realEstateType) {
        if (isNull(realEstateType) || realEstateType.isBlank()) {
            return null;
        }

        return RealEstateTypeDto.valueOf(realEstateType.toUpperCase());
    }
}
