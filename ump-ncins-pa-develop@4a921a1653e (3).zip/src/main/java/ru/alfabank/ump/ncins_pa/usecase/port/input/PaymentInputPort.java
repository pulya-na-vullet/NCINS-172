package ru.alfabank.ump.ncins_pa.usecase.port.input;

import java.util.Map;
import ru.alfabank.ump.ncins_pa.usecase.service.PaymentService;

public interface PaymentInputPort {

    PaymentService.SetHoldDto setHold(Map<String, Object> variables);

    PaymentService.CreatePaymentDto createPayment(Map<String, Object> variables);
}
