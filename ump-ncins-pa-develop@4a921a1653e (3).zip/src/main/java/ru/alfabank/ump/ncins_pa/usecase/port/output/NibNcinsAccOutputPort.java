package ru.alfabank.ump.ncins_pa.usecase.port.output;

import ru.alfabank.corp.openapi.ncins.acc.server.dto.ContractRequestDto;

public interface NibNcinsAccOutputPort {

    void createContract(ContractRequestDto contractRequestDto);
}
