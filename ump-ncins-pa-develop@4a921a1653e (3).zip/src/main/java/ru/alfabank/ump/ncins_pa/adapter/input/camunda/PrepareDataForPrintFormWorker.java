package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static java.lang.String.valueOf;
import static java.nio.charset.StandardCharsets.UTF_8;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.PrepareDataForPrintFormValidator.validate;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.ACCOUNT_DOCUMENT_TYPE;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.APPLICATION_SERVICE_CODE;
import static ru.alfabank.ump.ncins_pa.adapter.utils.ConstUtils.PRODUCT_CODE;
import static ru.alfabank.ump.ncins_pa.adapter.utils.XmlUtils.convertToXml;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.DocumentPrintFormOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.PrepareDataForPrintFormInputOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.PrepareDataForPrintFormInputVariables;

@Slf4j
@Component
public class PrepareDataForPrintFormWorker {

    private static final String START_LOG =
            "[processInstanceKey={}, businessKey={}] Начало подготовки данных для ПФ: {}";
    private static final String END_LOG =
            "[processInstanceKey={}, businessKey={}] Конец подготовки данных для ПФ: {}";
    private static final String XML_LOG =
            "[processInstanceKey={}, businessKey={}] Xml из prepareDataForPrintFormInputVariables: {}";

    /**
     * Подготавливает данные для печатной формы.
     *
     * @param prepareDataForPrintFormInputVariables Входные данные
     * @param job информация о задаче Zeebe
     */
    @JobWorker(type = "ump-prepare-documents-ncins-pa.get-report-data")
    public PrepareDataForPrintFormInputOutputVariables prepareDataForPrintForm(
            @Variable UUID businessKey,
            @VariablesAsType
                    PrepareDataForPrintFormInputVariables prepareDataForPrintFormInputVariables,
            final ActivatedJob job) {
        String processInstanceKey = valueOf(job.getProcessInstanceKey());
        log.info(START_LOG, processInstanceKey, businessKey, prepareDataForPrintFormInputVariables);
        validate(prepareDataForPrintFormInputVariables, processInstanceKey, businessKey);
        String xml =
                convertToXml(
                        prepareDataForPrintFormInputVariables, processInstanceKey, businessKey);
        log.info(XML_LOG, processInstanceKey, businessKey, xml);
        String reportData = Base64.getEncoder().encodeToString(xml.getBytes(UTF_8));
        PrepareDataForPrintFormInputOutputVariables prepareDataForPrintFormInputOutputVariables =
                PrepareDataForPrintFormInputOutputVariables.builder()
                        .serviceId(businessKey)
                        .serviceCode(APPLICATION_SERVICE_CODE)
                        .productCode(PRODUCT_CODE)
                        .documents(
                                List.of(
                                        new DocumentPrintFormOutputVariables(
                                                ACCOUNT_DOCUMENT_TYPE, reportData, false)))
                        .build();
        log.info(
                END_LOG,
                processInstanceKey,
                businessKey,
                prepareDataForPrintFormInputOutputVariables);
        return prepareDataForPrintFormInputOutputVariables;
    }
}
