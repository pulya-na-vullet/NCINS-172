package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import java.util.List;
import java.util.UUID;
import ump.products.api.dto.ProductDto;

public record AfterPrepareDocsInputVariables(
        UUID productId, List<ACDocumentDto> acDocuments, ProductDto productInfo) {}
