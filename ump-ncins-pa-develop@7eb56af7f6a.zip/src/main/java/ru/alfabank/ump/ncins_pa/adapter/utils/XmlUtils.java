package ru.alfabank.ump.ncins_pa.adapter.utils;

import static java.lang.String.format;
import static java.time.OffsetDateTime.now;
import static java.time.ZoneId.of;
import static java.util.Objects.nonNull;
import static ru.alfabank.ump.ncins_pa.adapter.utils.DateTimeUtils.formatOffsetDateTime;
import static ru.alfabank.ump.ncins_pa.adapter.utils.DateTimeUtils.getDateStartYearWithDash;
import static ru.alfabank.ump.ncins_pa.adapter.utils.DecimalUtils.formatDouble;

import java.io.StringWriter;
import java.util.UUID;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.PrepareDataForPrintFormInputVariables;

public final class XmlUtils {

    private static final String XML_ELEMENT_WRITE_ERROR_MESSAGE =
            "[processInstanceKey=%s, businessKey=%s] Ошибка при записи элемента в xml: tagName=%s, value=%s";
    private static final String CONVERT_TO_XML_ERROR_MESSAGE =
            "[processInstanceKey=%s, businessKey=%s] Ошибка при конвертации в xml: %s";

    public static String convertToXml(
            PrepareDataForPrintFormInputVariables prepareDataForPrintFormInputVariables,
            String processInstanceKey,
            UUID businessKey) {
        StringWriter stringWriter = new StringWriter();
        XMLOutputFactory factory = XMLOutputFactory.newInstance();
        XMLStreamWriter writer = null;
        try {
            writer = factory.createXMLStreamWriter(stringWriter);

            // Начало XML документа
            writer.writeStartDocument("UTF-8", "1.0");

            writer.writeStartElement("datasource");

            // Заполнение тегов на основе рекорда
            writeElement(
                    writer,
                    "contractNumber",
                    prepareDataForPrintFormInputVariables.contractNumber(),
                    processInstanceKey,
                    businessKey);
            writeElement(
                    writer,
                    "currentDate",
                    getDateStartYearWithDash(now(of("UTC"))),
                    processInstanceKey,
                    businessKey);
            writeElement(
                    writer,
                    "fullName",
                    prepareDataForPrintFormInputVariables.fullName(),
                    processInstanceKey,
                    businessKey);
            writeElement(
                    writer,
                    "inn",
                    prepareDataForPrintFormInputVariables.inn(),
                    processInstanceKey,
                    businessKey);
            writeElement(
                    writer,
                    "email",
                    prepareDataForPrintFormInputVariables.email(),
                    processInstanceKey,
                    businessKey);
            if (nonNull(prepareDataForPrintFormInputVariables.paymentAccount())) {
                writeElement(
                        writer,
                        "paymentAccount",
                        prepareDataForPrintFormInputVariables.paymentAccount(),
                        processInstanceKey,
                        businessKey);
            }
            writeElement(
                    writer,
                    "beginDate",
                    formatOffsetDateTime(prepareDataForPrintFormInputVariables.beginDate()),
                    processInstanceKey,
                    businessKey);
            writeElement(
                    writer,
                    "endDate",
                    formatOffsetDateTime(prepareDataForPrintFormInputVariables.endDate()),
                    processInstanceKey,
                    businessKey);
            if (nonNull(prepareDataForPrintFormInputVariables.insuranceSum())) {
                writeElement(
                        writer,
                        "insuranceSum",
                        formatDouble(prepareDataForPrintFormInputVariables.insuranceSum()),
                        processInstanceKey,
                        businessKey);
            }
            writeElement(
                    writer,
                    "insurancePremium",
                    formatDouble(prepareDataForPrintFormInputVariables.insurancePremium()),
                    processInstanceKey,
                    businessKey);

            // Закрытие корневого тега
            writer.writeEndElement();
            writer.writeEndDocument();
        } catch (XMLStreamException xmlStreamException) {
            throw new RuntimeException(
                    format(
                            CONVERT_TO_XML_ERROR_MESSAGE,
                            prepareDataForPrintFormInputVariables,
                            processInstanceKey,
                            businessKey),
                    xmlStreamException);
        } finally {
            closeXmlStreamWriter(
                    writer, prepareDataForPrintFormInputVariables, processInstanceKey, businessKey);
        }

        return stringWriter.toString();
    }

    private static void closeXmlStreamWriter(
            XMLStreamWriter xmlStreamWriter,
            PrepareDataForPrintFormInputVariables prepareDataForPrintFormInputVariables,
            String processInstanceKey,
            UUID businessKey) {
        if (xmlStreamWriter == null) {
            return;
        }
        try {
            xmlStreamWriter.flush();
            xmlStreamWriter.close();
        } catch (XMLStreamException xmlStreamException) {
            throw new RuntimeException(
                    format(
                            CONVERT_TO_XML_ERROR_MESSAGE,
                            processInstanceKey,
                            businessKey,
                            prepareDataForPrintFormInputVariables),
                    xmlStreamException);
        }
    }

    private static void writeElement(
            XMLStreamWriter writer,
            String tagName,
            String value,
            String processInstanceKey,
            UUID businessKey) {
        try {
            writer.writeStartElement(tagName);
            writer.writeCharacters(value != null ? value : "");
            writer.writeEndElement();
        } catch (XMLStreamException xmlStreamException) {
            throw new RuntimeException(
                    format(
                            XML_ELEMENT_WRITE_ERROR_MESSAGE,
                            processInstanceKey,
                            businessKey,
                            tagName,
                            value),
                    xmlStreamException);
        }
    }
}
