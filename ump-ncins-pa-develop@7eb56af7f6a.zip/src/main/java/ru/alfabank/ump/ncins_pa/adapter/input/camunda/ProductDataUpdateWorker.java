package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static java.lang.String.valueOf;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.ERROR;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.SUCCESS;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import java.util.Map;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductDataUpdateOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductUpdateBuildResult;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ProductUpdateType;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.service.ProductUpdateResolver;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ProductsOutputPort;
import ump.products.api.dto.ProductDto;

@Slf4j
@Component
@RequiredArgsConstructor
public class ProductDataUpdateWorker {

    private static final String START_LOG =
            "[processInstanceKey={}, businessKey={}] Начало обновления данных по продукту: {}";
    private static final String END_LOG =
            "[processInstanceKey={}, businessKey={}] Конец обновления данных по продукту: {}";
    private static final String PUT_PRODUCT_ERROR_MESSAGE =
            "[processInstanceKey={}, businessKey={}] Не удалось обновить данные по продукту: {}";

    private final ProductsOutputPort productsOutputPort;
    private final ProductUpdateResolver productUpdateResolver;

    /**
     * Обновляет данные по продукту.
     *
     * @param productUpdateType Тип обновления
     * @param job информация о задаче Zeebe
     */
    @JobWorker(type = "update-product")
    public ProductDataUpdateOutputVariables productDataUpdate(
            @Variable UUID businessKey,
            @Variable String productUpdateType,
            final ActivatedJob job) {
        String processInstanceKey = valueOf(job.getProcessInstanceKey());
        Map<String, Object> variables = job.getVariablesAsMap();

        log.info(START_LOG, processInstanceKey, businessKey, variables);

        ProductUpdateType updateType = ProductUpdateType.valueOf(productUpdateType);

        try {
            ProductUpdateBuildResult productUpdateBuildResult =
                    productUpdateResolver.build(updateType, variables);

            ProductDto putProduct =
                    productsOutputPort.putProduct(
                            productUpdateBuildResult.productId(),
                            productUpdateBuildResult.productCommonParamDto(),
                            processInstanceKey);
            log.info(END_LOG, processInstanceKey, businessKey, putProduct);
        } catch (Exception ex) {
            log.error(PUT_PRODUCT_ERROR_MESSAGE, processInstanceKey, businessKey, variables, ex);
            return new ProductDataUpdateOutputVariables(ERROR);
        }

        return new ProductDataUpdateOutputVariables(SUCCESS);
    }
}
