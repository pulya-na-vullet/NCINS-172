package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ContractValidator.validate;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ContractCreateInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.FinalisationDataOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.ContractMapper;
import ru.alfabank.ump.ncins_pa.usecase.port.output.NibNcinsAccOutputPort;

@Slf4j
@Component
@RequiredArgsConstructor
public class FinalisationWorker {

    private static final String START_LOG =
            "[processInstanceKey={}, businessKey={}] Создание договора в АБ.Страхование Учет: {}";
    private static final String END_LOG =
            "[processInstanceKey={}, businessKey={}] Процесс создания договора в АБ.Страхование Учет завершён: {}";
    private static final String ERROR_LOG =
            "[processInstanceKey={}, businessKey={}] Процесс создания договора в АБ.Страхование Учет завершился ошибкой: {}";

    private final NibNcinsAccOutputPort nibNcinsAccOutputPort;
    private final ContractMapper contractMapper;

    @JobWorker(type = "ump-finalisation-ncins-pa.create-contract")
    public FinalisationDataOutputVariables createContract(
            @Variable UUID businessKey,
            @VariablesAsType ContractCreateInputVariables variables,
            final ActivatedJob job) {
        String processInstanceKey = String.valueOf(job.getProcessInstanceKey());
        log.info(START_LOG, processInstanceKey, businessKey, variables);
        try {
            validate(variables);
            nibNcinsAccOutputPort.createContract(contractMapper.mapToContractDto(variables));
            log.info(END_LOG, processInstanceKey, businessKey, variables);
            return FinalisationDataOutputVariables.success();
        } catch (Exception e) {
            log.error(ERROR_LOG, processInstanceKey, businessKey, variables, e);
            return FinalisationDataOutputVariables.error(e.getMessage());
        }
    }
}
