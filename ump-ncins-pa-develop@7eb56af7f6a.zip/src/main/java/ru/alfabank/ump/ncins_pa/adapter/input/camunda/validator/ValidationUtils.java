package ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator;

import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationConstants.COMMON_ERROR_RESPONSE;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationConstants.ERR_BLANK;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationConstants.ERR_POSITIVE;

import java.util.List;
import lombok.experimental.UtilityClass;
import org.apache.commons.collections4.CollectionUtils;

@UtilityClass
public class ValidationUtils {

    public static void validateNotBlank(String value, String fieldName, List<String> errors) {
        if (isBlank(value)) {
            errors.add(ERR_BLANK.formatted(fieldName));
        }
    }

    public static void validateNotNull(Object value, String fieldName, List<String> errors) {
        if (isNull(value)) {
            errors.add(ERR_BLANK.formatted(fieldName));
        }
    }

    public static void validatePositive(Number value, String fieldName, List<String> errors) {
        if (value.doubleValue() <= 0) {
            errors.add(ERR_POSITIVE.formatted(fieldName));
        }
    }

    public static <T> void validateListNotEmpty(
            List<T> list, String fieldName, List<String> errors) {
        if (CollectionUtils.isEmpty(list)) {
            errors.add(ERR_BLANK.formatted(fieldName));
        }
    }

    public static void throwIfErrorsExist(List<String> errors) {
        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(
                    COMMON_ERROR_RESPONSE.formatted(String.join(" ", errors)));
        }
    }
}
