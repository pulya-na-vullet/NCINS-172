package ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator;

import static java.util.Objects.nonNull;
import static org.apache.commons.collections.CollectionUtils.isEmpty;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationConstants.ERR_BLANK;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.throwIfErrorsExist;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validateNotBlank;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validateNotNull;

import java.util.ArrayList;
import java.util.List;
import lombok.experimental.UtilityClass;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ACDocumentDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterPrepareDocsInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterSigningInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterSigningVariables;

@UtilityClass
public class ProductDataUpdateValidator {

    private static final String PRODUCT_ID = "productId";
    private static final String PRODUCT_INFO = "productInfo";

    public static void validate(AfterPrepareDocsInputVariables input) {
        List<String> errors = new ArrayList<>();

        validateNotNull(input, "afterPrepareDocsInputVariables", errors);
        validateNotNull(input.productId(), PRODUCT_ID, errors);
        validateNotNull(input.productInfo(), PRODUCT_INFO, errors);
        validateAcDocuments(input.acDocuments(), errors);

        throwIfErrorsExist(errors);
    }

    public static void validate(AfterSigningInputVariables input) {
        List<String> errors = new ArrayList<>();

        validateNotNull(input, "afterSigningInputVariables", errors);
        validateNotNull(input.productId(), PRODUCT_ID, errors);
        validateVariables(input.variables(), errors);
        validateNotNull(input.productInfo(), PRODUCT_INFO, errors);

        throwIfErrorsExist(errors);
    }

    private static void validateAcDocuments(List<ACDocumentDto> acDocuments, List<String> errors) {
        if (isEmpty(acDocuments)) {
            errors.add(ERR_BLANK.formatted("acDocuments"));
            return;
        }

        ACDocumentDto first = acDocuments.getFirst();

        validateNotNull(first.acId(), "acId", errors);
        validateNotBlank(first.type(), "type", errors);
    }

    private static void validateVariables(AfterSigningVariables variables, List<String> errors) {
        validateNotNull(variables, "variables", errors);

        if (nonNull(variables)) {
            validateNotNull(variables.agreementLink(), "agreementLink", errors);
        }
    }
}
