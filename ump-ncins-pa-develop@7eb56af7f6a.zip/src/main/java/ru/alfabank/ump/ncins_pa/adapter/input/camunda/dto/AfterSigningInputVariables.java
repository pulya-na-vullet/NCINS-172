package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import java.util.UUID;
import ump.products.api.dto.ProductDto;

public record AfterSigningInputVariables(
        UUID productId, AfterSigningVariables variables, ProductDto productInfo) {}
