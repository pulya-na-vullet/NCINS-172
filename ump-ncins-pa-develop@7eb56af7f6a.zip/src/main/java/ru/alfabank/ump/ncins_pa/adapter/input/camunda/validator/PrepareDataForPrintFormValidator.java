package ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator;

import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.throwIfErrorsExist;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validateNotBlank;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validateNotNull;

import java.util.ArrayList;
import java.util.List;
import lombok.experimental.UtilityClass;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.PrepareDataForPrintFormInputVariables;

@UtilityClass
public class PrepareDataForPrintFormValidator {

    public static void validate(
            PrepareDataForPrintFormInputVariables prepareDataForPrintFormInputVariables) {
        List<String> errors = new ArrayList<>();

        validateNotNull(
                prepareDataForPrintFormInputVariables,
                "prepareDataForPrintFormInputVariables",
                errors);
        validateNotNull(prepareDataForPrintFormInputVariables.programId(), "programId", errors);
        validateNotBlank(prepareDataForPrintFormInputVariables.fullName(), "fullName", errors);
        validateNotBlank(prepareDataForPrintFormInputVariables.inn(), "inn", errors);
        validateNotBlank(prepareDataForPrintFormInputVariables.email(), "email", errors);
        validateNotBlank(
                prepareDataForPrintFormInputVariables.contractNumber(), "contractNumber", errors);
        validateNotNull(prepareDataForPrintFormInputVariables.beginDate(), "beginDate", errors);
        validateNotNull(prepareDataForPrintFormInputVariables.endDate(), "endDate", errors);
        validateNotBlank(
                prepareDataForPrintFormInputVariables.currentDate(), "currentDate", errors);
        validateNotNull(
                prepareDataForPrintFormInputVariables.insurancePremium(),
                "insurancePremium",
                errors);

        throwIfErrorsExist(errors);
    }
}
