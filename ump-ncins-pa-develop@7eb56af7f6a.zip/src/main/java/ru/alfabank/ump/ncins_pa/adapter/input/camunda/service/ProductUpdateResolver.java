package ru.alfabank.ump.ncins_pa.adapter.input.camunda.service;

import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ProductDataUpdateValidator.validate;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterPrepareDocsInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterSigningInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductUpdateBuildResult;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ProductUpdateType;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.ProductsMapper;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductNonCreditInsuranceDto;

@Component
@RequiredArgsConstructor
public class ProductUpdateResolver {
    private final ProductsMapper productsMapper;
    private final ObjectMapper objectMapper;

    public ProductUpdateBuildResult build(
            ProductUpdateType updateType, Map<String, Object> variables) {
        return switch (updateType) {
            case AFTER_PREPARE_DOCS -> buildAfterPrepareDocs(variables);
            case AFTER_SIGNING -> buildAfterSigning(variables);
        };
    }

    private ProductUpdateBuildResult buildAfterPrepareDocs(Map<String, Object> variables) {
        AfterPrepareDocsInputVariables input =
                objectMapper.convertValue(variables, AfterPrepareDocsInputVariables.class);
        validate(input);

        ProductCommonParamDto dto = productsMapper.toProductCommonParamDto(input.productInfo());
        ProductNonCreditInsuranceDto props =
                (ProductNonCreditInsuranceDto) dto.getProductProperties();

        props.setContractLink(input.acDocuments().getFirst().acId().toString());

        return new ProductUpdateBuildResult(input.productId(), dto);
    }

    private ProductUpdateBuildResult buildAfterSigning(Map<String, Object> variables) {
        AfterSigningInputVariables input =
                objectMapper.convertValue(variables, AfterSigningInputVariables.class);
        validate(input);

        ProductCommonParamDto dto = productsMapper.toProductCommonParamDto(input.productInfo());
        ProductNonCreditInsuranceDto props =
                (ProductNonCreditInsuranceDto) dto.getProductProperties();

        props.setAgreementLink(input.variables().agreementLink().toString());

        return new ProductUpdateBuildResult(input.productId(), dto);
    }
}
