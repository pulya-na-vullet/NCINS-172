package ru.alfabank.ump.ncins_pa.adapter.utils;

public final class ConstUtils {

    public static final String APPLICATION_SERVICE_CODE = "APPLICATION";
    public static final String PRODUCT_CODE = "NON_CREDIT_INSURANCE";
    public static final String ACCOUNT_DOCUMENT_TYPE = "CONTRACT_ACCOUNT_BLOCK";
}
