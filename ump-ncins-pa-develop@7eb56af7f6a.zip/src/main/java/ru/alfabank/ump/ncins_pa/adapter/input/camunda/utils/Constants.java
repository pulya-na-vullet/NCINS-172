package ru.alfabank.ump.ncins_pa.adapter.input.camunda.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {
    public static final String INN = "inn";
    public static final String PROGRAM_ID = "programId";
}
