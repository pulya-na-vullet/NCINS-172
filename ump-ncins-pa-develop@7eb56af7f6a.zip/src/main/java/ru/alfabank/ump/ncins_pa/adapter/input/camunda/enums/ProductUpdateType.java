package ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums;

public enum ProductUpdateType {
    AFTER_PREPARE_DOCS,
    AFTER_SIGNING,
}
