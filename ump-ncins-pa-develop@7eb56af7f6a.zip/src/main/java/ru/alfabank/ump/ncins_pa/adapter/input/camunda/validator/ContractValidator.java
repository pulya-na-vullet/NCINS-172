package ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator;

import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationConstants.ERR_BLANK;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.throwIfErrorsExist;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validateListNotEmpty;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validateNotBlank;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validateNotNull;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator.ValidationUtils.validatePositive;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.EmailValidator;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ContractCreateInputVariables;

@UtilityClass
public class ContractValidator {
    private static final String ERR_UUID = "%s должен быть в формате UUID.";

    public static void validate(ContractCreateInputVariables input) {
        List<String> errors = new ArrayList<>();

        validatePositive(input.programId(), "programId", errors);
        validateNotBlank(input.inn(), "inn", errors);
        validateEmail(input.email(), errors);
        validateNotBlank(input.contractNumber(), "contractNumber", errors);
        validateNotNull(input.beginDate(), "beginDate", errors);
        validateNotNull(input.endDate(), "endDate", errors);
        validateNotNull(input.signDate(), "signDate", errors);
        validatePositive(input.insurancePremium(), "insurancePremium", errors);
        validatePositive(input.duration(), "duration", errors);
        validateNotBlank(input.paymentType(), "paymentType", errors);
        validateListNotEmpty(input.insuranceObjects(), "insuranceObjects", errors);
        validateNotBlank(input.ownerId(), "ownerId", errors);
        validateNotBlank(input.phoneNumber(), "phoneNumber", errors);
        validateNotBlank(input.sellerChannel(), "sellerChannel", errors);
        validateUuid(input.contractLink(), "contractLink", errors);
        validateUuid(input.agreementLink(), "agreementLink", errors);

        throwIfErrorsExist(errors);
    }

    private static void validateEmail(String email, List<String> errors) {
        if (StringUtils.isBlank(email)) {
            errors.add(ERR_BLANK.formatted("email"));
            return;
        }
        if (!EmailValidator.getInstance().isValid(email)) {
            errors.add("email имеет некорректный формат.");
        }
    }

    private static void validateUuid(String value, String fieldName, List<String> errors) {
        if (StringUtils.isBlank(value)) {
            errors.add(ERR_BLANK.formatted(fieldName));
            return;
        }

        try {
            UUID.fromString(value);
        } catch (IllegalArgumentException e) {
            errors.add(ERR_UUID.formatted(fieldName));
        }
    }
}
