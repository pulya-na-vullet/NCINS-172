package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import java.util.UUID;
import ump.products.api.dto.ProductCommonParamDto;

public record ProductUpdateBuildResult(
        UUID productId, ProductCommonParamDto productCommonParamDto) {}
