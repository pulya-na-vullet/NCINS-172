package ru.alfabank.ump.ncins_pa.adapter.input.camunda.validator;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ValidationConstants {
    public static final String ERR_BLANK = "%s не может быть пустым.";
    public static final String COMMON_ERROR_RESPONSE = "Ошибки валидации: %s";
    public static final String ERR_POSITIVE = "%s должен быть положительным числом.";
}
