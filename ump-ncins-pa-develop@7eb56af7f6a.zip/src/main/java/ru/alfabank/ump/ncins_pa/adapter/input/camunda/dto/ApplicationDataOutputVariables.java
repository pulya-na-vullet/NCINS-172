package ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.Builder;
import ru.alfabank.corp.openapi.ncins.acc.server.dto.InsuranceObjectDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode;
import ump.products.api.dto.ProductDto;

@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ApplicationDataOutputVariables(
        ResponseCode getProcessParams,
        int programId,
        String fullName,
        UUID productId,
        String inn,
        String email,
        String contractNumber,
        OffsetDateTime beginDate,
        OffsetDateTime endDate,
        String currentDate,
        double insuranceSum,
        double insurancePremium,
        OffsetDateTime signDate,
        String debitAccount,
        int duration,
        String paymentType,
        String contractLink,
        String policyLink,
        String agreementLink,
        List<InsuranceObjectDto> insuranceObjects,
        String ownerId,
        String ogrn,
        String phoneNumber,
        String legalAddress,
        String sellerId,
        String sellerChannel,
        String paymentAccount,
        String processInstanceKey,
        List<DocumentDto> documents,
        ProductDto productInfo,
        String systemCode,
        Map<String, Object> variables) {

    public static ApplicationDataOutputVariables error() {
        return ApplicationDataOutputVariables.builder()
                .getProcessParams(ResponseCode.ERROR)
                .build();
    }
}
