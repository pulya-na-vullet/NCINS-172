package ru.alfabank.ump.ncins_pa.adapter.input.camunda.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ACDocumentDto;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterPrepareDocsInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterSigningInputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.AfterSigningVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductUpdateBuildResult;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ProductUpdateType;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.mapper.ProductsMapper;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductDto;
import ump.products.api.dto.ProductNonCreditInsuranceDto;

@DisplayName("ProductUpdateResolver - Модульное тестирование")
@ExtendWith(MockitoExtension.class)
class ProductUpdateResolverTest {

    @Mock private ProductsMapper productsMapper;

    @Mock private ObjectMapper objectMapper;

    @InjectMocks private ProductUpdateResolver resolver;

    private static final UUID PRODUCT_ID = UUID.fromString("660e8400-e29b-41d4-a716-446655110001");
    private static final UUID AC_ID = UUID.fromString("770e8400-e29b-41d4-a716-446655110002");
    private static final UUID AGREEMENT_LINK =
            UUID.fromString("880e8400-e29b-41d4-a716-446655110003");

    private ProductNonCreditInsuranceDto createProductNonCreditInsuranceDto() {
        var dto = new ProductNonCreditInsuranceDto();
        dto.setPolicyLink("old-policy-link");
        return dto;
    }

    private ProductCommonParamDto createProductCommonParamDto() {
        var dto = new ProductCommonParamDto();
        dto.setProductProperties(createProductNonCreditInsuranceDto());
        return dto;
    }

    @Test
    @DisplayName("Должен вызвать buildAfterPrepareDocs при типе AFTER_PREPARE_DOCS")
    void shouldBuildAfterPrepareDocsWhenTypeIsAfterPrepareDocs() {
        var variables =
                Map.of(
                        "productId",
                        PRODUCT_ID,
                        "acDocuments",
                        List.of(Map.of("type", "CREDIT", "acId", AC_ID)),
                        "productInfo",
                        new ProductDto());
        var input =
                new AfterPrepareDocsInputVariables(
                        PRODUCT_ID, List.of(new ACDocumentDto("CREDIT", AC_ID)), new ProductDto());
        var productCommonParamDto = createProductCommonParamDto();

        when(objectMapper.convertValue(variables, AfterPrepareDocsInputVariables.class))
                .thenReturn(input);
        when(productsMapper.toProductCommonParamDto(input.productInfo()))
                .thenReturn(productCommonParamDto);

        ProductUpdateBuildResult result =
                resolver.build(ProductUpdateType.AFTER_PREPARE_DOCS, variables);

        assertNotNull(result);
        assertEquals(PRODUCT_ID, result.productId());
        assertSame(productCommonParamDto, result.productCommonParamDto());

        var props = (ProductNonCreditInsuranceDto) productCommonParamDto.getProductProperties();
        assertEquals(AC_ID.toString(), props.getContractLink());
    }

    @Test
    @DisplayName("Должен вызвать buildAfterSigning при типе AFTER_SIGNING")
    void shouldBuildAfterSigningWhenTypeIsAfterSigning() {
        var variables =
                Map.of(
                        "productId",
                        PRODUCT_ID,
                        "variables",
                        Map.of("id", PRODUCT_ID, "agreementLink", AGREEMENT_LINK),
                        "productInfo",
                        new ProductDto());
        var input =
                new AfterSigningInputVariables(
                        PRODUCT_ID,
                        new AfterSigningVariables(PRODUCT_ID, AGREEMENT_LINK),
                        new ProductDto());
        var productCommonParamDto = createProductCommonParamDto();

        when(objectMapper.convertValue(variables, AfterSigningInputVariables.class))
                .thenReturn(input);
        when(productsMapper.toProductCommonParamDto(input.productInfo()))
                .thenReturn(productCommonParamDto);

        ProductUpdateBuildResult result =
                resolver.build(ProductUpdateType.AFTER_SIGNING, variables);

        assertNotNull(result);
        assertEquals(PRODUCT_ID, result.productId());
        assertSame(productCommonParamDto, result.productCommonParamDto());

        assertNotNull(result);
        assertEquals(PRODUCT_ID, result.productId());
        assertSame(productCommonParamDto, result.productCommonParamDto());

        var props = (ProductNonCreditInsuranceDto) productCommonParamDto.getProductProperties();
        assertEquals(AGREEMENT_LINK.toString(), props.getAgreementLink());
    }

    @Test
    @DisplayName("Должен установить contractLink из acDocuments[0].acId для AFTER_PREPARE_DOCS")
    void shouldSetContractLinkFromFirstDocumentAcId() {
        var variables =
                Map.of(
                        "productId",
                        PRODUCT_ID,
                        "acDocuments",
                        List.of(Map.of("type", "CREDIT", "acId", AC_ID)),
                        "productInfo",
                        new ProductDto());
        var input =
                new AfterPrepareDocsInputVariables(
                        PRODUCT_ID, List.of(new ACDocumentDto("CREDIT", AC_ID)), new ProductDto());
        var productCommonParamDto = createProductCommonParamDto();

        when(objectMapper.convertValue(variables, AfterPrepareDocsInputVariables.class))
                .thenReturn(input);
        when(productsMapper.toProductCommonParamDto(input.productInfo()))
                .thenReturn(productCommonParamDto);

        ProductUpdateBuildResult result =
                resolver.build(ProductUpdateType.AFTER_PREPARE_DOCS, variables);

        assertNotNull(result);
        assertEquals(PRODUCT_ID, result.productId());
        assertSame(productCommonParamDto, result.productCommonParamDto());

        var props = (ProductNonCreditInsuranceDto) productCommonParamDto.getProductProperties();
        assertEquals(AC_ID.toString(), props.getContractLink());
    }

    @Test
    @DisplayName("Должен установить agreementLink из variables.agreementLink для AFTER_SIGNING")
    void shouldSetAgreementLinkFromVariables() {
        var variables =
                Map.of(
                        "productId",
                        PRODUCT_ID,
                        "variables",
                        Map.of("id", PRODUCT_ID, "agreementLink", AGREEMENT_LINK),
                        "productInfo",
                        new ProductDto());
        var input =
                new AfterSigningInputVariables(
                        PRODUCT_ID,
                        new AfterSigningVariables(PRODUCT_ID, AGREEMENT_LINK),
                        new ProductDto());
        var productCommonParamDto = createProductCommonParamDto();

        when(objectMapper.convertValue(variables, AfterSigningInputVariables.class))
                .thenReturn(input);
        when(productsMapper.toProductCommonParamDto(input.productInfo()))
                .thenReturn(productCommonParamDto);

        ProductUpdateBuildResult result =
                resolver.build(ProductUpdateType.AFTER_SIGNING, variables);

        assertNotNull(result);
        assertEquals(PRODUCT_ID, result.productId());
        assertSame(productCommonParamDto, result.productCommonParamDto());

        var props = (ProductNonCreditInsuranceDto) productCommonParamDto.getProductProperties();
        assertEquals(AGREEMENT_LINK.toString(), props.getAgreementLink());
    }

    @Test
    @DisplayName(
            "Должен пробросить processInstanceKey и businessKey в валидатор для AFTER_PREPARE_DOCS")
    void shouldPassProcessInstanceKeyAndBusinessKeyToValidatorForAfterPrepareDocs() {
        var variables =
                Map.of(
                        "productId",
                        PRODUCT_ID,
                        "acDocuments",
                        List.of(Map.of("type", "CREDIT", "acId", AC_ID)),
                        "productInfo",
                        new ProductDto());
        var input =
                new AfterPrepareDocsInputVariables(
                        PRODUCT_ID, List.of(new ACDocumentDto("CREDIT", AC_ID)), new ProductDto());
        var productCommonParamDto = createProductCommonParamDto();

        when(objectMapper.convertValue(variables, AfterPrepareDocsInputVariables.class))
                .thenReturn(input);
        when(productsMapper.toProductCommonParamDto(input.productInfo()))
                .thenReturn(productCommonParamDto);

        resolver.build(ProductUpdateType.AFTER_PREPARE_DOCS, variables);
        verify(productsMapper).toProductCommonParamDto(input.productInfo());
    }

    @Test
    @DisplayName("Должен бросить исключение при пустом списке acDocuments")
    void shouldThrowExceptionWhenAcDocumentsIsEmpty() {
        var variables =
                Map.of(
                        "productId",
                        PRODUCT_ID,
                        "acDocuments",
                        List.of(),
                        "productInfo",
                        new ProductDto());
        var input = new AfterPrepareDocsInputVariables(PRODUCT_ID, List.of(), new ProductDto());

        when(objectMapper.convertValue(variables, AfterPrepareDocsInputVariables.class))
                .thenReturn(input);

        assertThrows(
                RuntimeException.class,
                () -> resolver.build(ProductUpdateType.AFTER_PREPARE_DOCS, variables));
    }

    @Test
    @DisplayName("Должен бросить NullPointerException при null updateType")
    void shouldThrowExceptionWhenUpdateTypeIsNull() {
        var variables = Map.<String, Object>of();

        assertThrows(NullPointerException.class, () -> resolver.build(null, variables));
    }

    @Test
    @DisplayName("Должен бросить исключение при malformed variables для AFTER_PREPARE_DOCS")
    void shouldThrowExceptionWhenVariablesMapIsMalformedForAfterPrepareDocs() {
        var variables = Map.<String, Object>of("someKey", "someValue");
        var malformedInput = new AfterPrepareDocsInputVariables(null, null, null);

        when(objectMapper.convertValue(variables, AfterPrepareDocsInputVariables.class))
                .thenReturn(malformedInput);

        assertThrows(
                IllegalArgumentException.class,
                () -> resolver.build(ProductUpdateType.AFTER_PREPARE_DOCS, variables));
    }

    @Test
    @DisplayName("Должен бросить исключение при malformed variables для AFTER_SIGNING")
    void shouldThrowExceptionWhenVariablesMapIsMalformedForAfterSigning() {
        var variables = Map.<String, Object>of("someKey", "someValue");
        var malformedInput = new AfterSigningInputVariables(null, null, null);

        when(objectMapper.convertValue(variables, AfterSigningInputVariables.class))
                .thenReturn(malformedInput);

        assertThrows(
                IllegalArgumentException.class,
                () -> resolver.build(ProductUpdateType.AFTER_SIGNING, variables));
    }
}
