package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.ERROR;
import static ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ResponseCode.SUCCESS;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductDataUpdateOutputVariables;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.dto.ProductUpdateBuildResult;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.enums.ProductUpdateType;
import ru.alfabank.ump.ncins_pa.adapter.input.camunda.service.ProductUpdateResolver;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ProductsOutputPort;
import ump.products.api.dto.ProductCommonParamDto;
import ump.products.api.dto.ProductDto;
import ump.products.api.dto.ProductNonCreditInsuranceDto;

@DisplayName(
        "ProductDataUpdateWorkerIT - Интеграционное тестирование \"Обновление данных по продукту\"")
@ExtendWith(MockitoExtension.class)
class ProductDataUpdateWorkerIT {

    @Mock private ProductsOutputPort productsOutputPort;
    @Mock private ProductUpdateResolver productUpdateResolver;
    @Mock private ActivatedJob job;

    @InjectMocks private ProductDataUpdateWorker worker;

    private static final UUID BUSINESS_KEY =
            UUID.fromString("550e8400-e29b-41d4-a716-446655110000");
    private static final long PROCESS_INSTANCE_KEY = 12345L;
    private static final UUID PRODUCT_ID = UUID.fromString("660e8400-e29b-41d4-a716-446655110001");

    private ProductNonCreditInsuranceDto createProductNonCreditInsuranceDto() {
        var dto = new ProductNonCreditInsuranceDto();
        dto.setPolicyLink("old-policy-link");
        return dto;
    }

    private ProductCommonParamDto createProductCommonParamDto() {
        var dto = new ProductCommonParamDto();
        dto.setProductProperties(createProductNonCreditInsuranceDto());
        return dto;
    }

    @Test
    @DisplayName("Должен успешно обновить данные по продукту и вернуть SUCCESS")
    void shouldUpdateProductDataSuccessfully() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var productCommonParamDto = createProductCommonParamDto();
        var buildResult = new ProductUpdateBuildResult(PRODUCT_ID, productCommonParamDto);

        when(productUpdateResolver.build(eq(ProductUpdateType.AFTER_PREPARE_DOCS), anyMap()))
                .thenReturn(buildResult);

        var expectedPutProduct = new ProductDto();
        when(productsOutputPort.putProduct(
                        eq(PRODUCT_ID),
                        eq(productCommonParamDto),
                        eq(String.valueOf(PROCESS_INSTANCE_KEY))))
                .thenReturn(expectedPutProduct);

        // when
        ProductDataUpdateOutputVariables result =
                worker.productDataUpdate(BUSINESS_KEY, "AFTER_PREPARE_DOCS", job);

        // then
        assertNotNull(result);
        assertEquals(SUCCESS, result.getProcessParams());

        verify(productUpdateResolver).build(eq(ProductUpdateType.AFTER_PREPARE_DOCS), anyMap());
        verify(productsOutputPort)
                .putProduct(
                        eq(PRODUCT_ID),
                        eq(productCommonParamDto),
                        eq(String.valueOf(PROCESS_INSTANCE_KEY)));
    }

    @Test
    @DisplayName("Должен вернуть ERROR при исключении в productsOutputPort.putProduct")
    void shouldReturnErrorWhenPutProductThrowsException() {
        // given
        when(job.getProcessInstanceKey()).thenReturn(PROCESS_INSTANCE_KEY);

        var productCommonParamDto = createProductCommonParamDto();
        var buildResult = new ProductUpdateBuildResult(PRODUCT_ID, productCommonParamDto);

        when(productUpdateResolver.build(eq(ProductUpdateType.AFTER_PREPARE_DOCS), anyMap()))
                .thenReturn(buildResult);

        when(productsOutputPort.putProduct(
                        eq(PRODUCT_ID),
                        eq(productCommonParamDto),
                        eq(String.valueOf(PROCESS_INSTANCE_KEY))))
                .thenThrow(new RuntimeException("Ошибка при обновлении продукта"));

        // when
        ProductDataUpdateOutputVariables result =
                worker.productDataUpdate(BUSINESS_KEY, "AFTER_PREPARE_DOCS", job);

        // then
        assertNotNull(result);
        assertEquals(ERROR, result.getProcessParams());
    }
}
