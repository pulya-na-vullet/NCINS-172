plugins {
    id("ru.alfabank.ump.ump-microservice-plugin") version "4.0.4"
    id("com.diffplug.spotless") version "8.4.0"
}

group = "ru.alfabank.ump"

val instancioVersion = "4.8.0"
val utilityLibVersion = "2.0.0"
val resilience4jVersion = "2.2.0"
val camundaStarterVersion = "0.1.0"
val camundaTestVersion = "8.7.20"

microservice {
    dependencyPack
        .microservice()
        .lombok()
        .mapstruct()
}

repositories {
    maven("https://binary.alfabank.ru/artifactory/public")
    maven("https://binary.alfabank.ru/artifactory/ump-mvn-releases")
}

dependencies {
    //common
    implementation("ru.alfabank.ump:ump-utility-lib:2.0.0")
    implementation("org.springframework.cloud:spring-cloud-starter-openfeign")
    implementation("ru.alfalab.starter.logging:spring-boot-starter-alfalab-logging")
    implementation("io.github.resilience4j:resilience4j-spring-boot3:2.2.0")

    //camunda
    implementation("ru.alfabank.ump:ump-camunda-starter:0.1.0")

    //test
    testImplementation("org.instancio:instancio-junit:4.8.0")
    testImplementation("io.camunda:camunda-process-test-spring:8.7.20")
}

quality {
    strict = false
}

spotless {
    java {
        googleJavaFormat("1.22.0")
            .aosp()
    }
}

tasks.jacocoTestReport {
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}
