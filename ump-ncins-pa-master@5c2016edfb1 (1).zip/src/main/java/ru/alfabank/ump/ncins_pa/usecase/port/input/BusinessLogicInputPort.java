package ru.alfabank.ump.ncins_pa.usecase.port.input;

public interface BusinessLogicInputPort {

    void process(Object inputData);
}
