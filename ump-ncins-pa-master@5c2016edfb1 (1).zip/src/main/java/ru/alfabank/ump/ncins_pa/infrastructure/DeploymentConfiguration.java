package ru.alfabank.ump.ncins_pa.infrastructure;

import io.camunda.zeebe.spring.client.annotation.Deployment;
import org.springframework.context.annotation.Configuration;

@Configuration
@Deployment(
        resources = {
            "classpath:bpmn/example-process-pa.bpmn"
        })
public class DeploymentConfiguration {}
