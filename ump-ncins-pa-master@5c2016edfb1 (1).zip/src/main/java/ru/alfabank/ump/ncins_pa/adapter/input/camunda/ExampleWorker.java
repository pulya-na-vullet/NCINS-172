package ru.alfabank.ump.ncins_pa.adapter.input.camunda;

import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.usecase.port.input.BusinessLogicInputPort;

@Slf4j
@Component
@RequiredArgsConstructor
public class ExampleWorker {

    private final BusinessLogicInputPort businessLogicInputPort;

    @JobWorker(type = "process-id.service-task-type")
    public void processServiceTask(@VariablesAsType Map<String, Object> variables) {
        businessLogicInputPort.process(variables);
    }
}
