package ru.alfabank.ump.ncins_pa.usecase.port.output;

public interface ExampleOutputPort {

    void execute();
}
