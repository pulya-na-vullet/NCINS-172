package ru.alfabank.ump.ncins_pa.adapter.output.soap;

import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ExampleOutputPort;

@Component
public class ExampleSoapAdapter implements ExampleOutputPort {

    @Override
    public void execute() {
        // integration
    }
}
