package ru.alfabank.ump.ncins_pa.adapter.output.rest;

import org.springframework.stereotype.Component;
import ru.alfabank.ump.ncins_pa.usecase.port.output.ExampleOutputPort;

@Component
public class ExampleRestAdapter implements ExampleOutputPort {

    @Override
    public void execute() {
        // integration
    }
}
