package ru.alfabank.ump.ncins_pa.domain;

public class ExampleModel {}
