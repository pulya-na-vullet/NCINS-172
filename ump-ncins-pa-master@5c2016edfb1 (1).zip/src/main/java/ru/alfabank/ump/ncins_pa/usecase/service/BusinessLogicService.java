package ru.alfabank.ump.ncins_pa.usecase.service;

import org.springframework.stereotype.Service;
import ru.alfabank.ump.ncins_pa.usecase.port.input.BusinessLogicInputPort;

@Service
public class BusinessLogicService implements BusinessLogicInputPort {

    @Override
    public void process(Object inputData) {
        // business logic
    }
}
