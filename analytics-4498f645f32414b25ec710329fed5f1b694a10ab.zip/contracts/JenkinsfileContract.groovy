def UUID_DIR = UUID.randomUUID().toString()

pipeline {
    agent {
        kubernetes {
            inheritFrom 'debian12-jdk21-node16'
            defaultContainer 'debian12-jdk21-node16-builder'
            customWorkspace UUID_DIR
        }
    }

    triggers {
        GenericTrigger(
                genericVariables: [
                        [key: 'branchName', value: '$.branch', expressionType: 'JSONPath', defaultValue: 'master'],
                        [key: 'description', value: '$.description', expressionType: 'JSONPath', defaultValue: 'not title']
                ],
                causeString: '$description',
                token: 'analytics'
        )
    }

    options {
        buildDiscarder(logRotator(daysToKeepStr: '7', artifactDaysToKeepStr: '7'))
        timeout(time: 1, unit: 'HOURS')
        ansiColor('xterm')
    }

    environment {
        BRANCH_NAME_CLEAN = "${env.branchName.replaceAll('refs/heads/', '')}"
        IS_RELEASE_BRANCH = "${env.BRANCH_NAME_CLEAN.startsWith('release/')}"
        VERSION_SUFFIX = "${IS_RELEASE_BRANCH == 'true' ? '' : '-DEMO'}"
    }

    stages {
        stage("Reading parameters") {
            steps {
                script {
                    properties([
                            parameters([
                                    string(name: "branchName", description: "Ветка", defaultValue: 'master'),
                                    string(name: "credentialsId", description: "Реквизиты для публикации в artifactory", defaultValue: 'tech_ump_jenkins')
                            ])
                    ])
                }
            }
        }
        stage("Updating project from git") {
            steps {
                checkout([$class: 'GitSCM',
                          branches: [[name: "*/${branchName}"]],
                          userRemoteConfigs: [[credentialsId: 'jenkins-git', url: 'ssh://git@git.moscow.alfaintra.net/scm/ump/analytics.git']]])
            }
        }
        stage('Contract validation') {
            when {
                expression { env.IS_RELEASE_BRANCH == 'true' }
            }
            steps {
                script {
                    ansiColor('xterm') {
                        sh "chmod +x ./gradlew"
                        sh './gradlew contracts:validator'
                    }
                }
            }
        }
        stage('Check version contracts') {
            when {
                expression { env.IS_RELEASE_BRANCH == 'true' }
            }
            steps {
                script {
                    sshagent(credentials: ['tech_ump_bb_conf']) {
                        sh "chmod a+x scripts/check.sh"
                        sh "scripts/check.sh"
                    }
                }
            }
        }
        stage('Publish contract and client') {
            steps {
                script {
                    env.GRADLE_USER_HOME = "${env.WORKSPACE}/.gradle"
                    sh "export LANG=C.UTF-8 && locale"
                    sh "chmod +x ./gradlew"
                    git branch: "${params.branchName}", credentialsId: 'jenkins-git', url: 'ssh://git@git.moscow.alfaintra.net/scm/ump/analytics.git'
                    withCredentials([usernamePassword(credentialsId: "${params.credentialsId}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
                        def versionParam = env.VERSION_SUFFIX
                        sh "./gradlew --info contracts:build --stacktrace --console=plain -PversionSuffix=${versionParam}"
                        sh "./gradlew --info contracts:packAll --stacktrace --console=plain -PversionSuffix=${versionParam}"
                        sh "./gradlew --info contracts:publish --stacktrace --console=plain -PversionSuffix=${versionParam}"
                    }
                }
            }
        }
    }
    post {
        failure {
            script {
                if (env.IS_RELEASE_BRANCH == 'true') {
                    notifyBitbucketWithState('FAILED')
                    withCredentials([usernamePassword(credentialsId: 'rocket-chat-ci', usernameVariable: 'USER_FROM_CRED', passwordVariable: 'PASS_FROM_CRED')]) {
                        env.ROCKET_CHAT_USER = USER_FROM_CRED
                        env.ROCKET_CHAT_PASS = PASS_FROM_CRED
                        env.BUILD_URL = BUILD_URL
                        env.CHANNEL = "ump-analytics"
                        sh '''
                    chmod a+x gradle/scripts/sendMessageFailed.sh
                    gradle/scripts/sendMessageFailed.sh \
                        "$CHANNEL" \
                        "$BUILD_URL" 
                    '''
                    }
                } else {
                    echo "Not a release branch, skipping failure notification"
                }
            }
        }
        success {
            script {
                if (env.IS_RELEASE_BRANCH == 'true') {
                    notifyBitbucketWithState('SUCCESS')
                    sh "chmod a+x scripts/sendMessage.sh"
                    sh "scripts/sendMessage.sh ump-analytics"
                    withCredentials([usernamePassword(credentialsId: 'rocket-chat-ci', usernameVariable: 'USER_FROM_CRED', passwordVariable: 'PASS_FROM_CRED')]) {
                        env.ROCKET_CHAT_USER = USER_FROM_CRED
                        env.ROCKET_CHAT_PASS = PASS_FROM_CRED
                        env.CHANNEL = "ump-analytics"
                        sh '''
                    chmod a+x gradle/scripts/sendMessage.sh
                    gradle/scripts/sendMessage.sh \
                        "$CHANNEL"
                    '''
                    }
                } else {
                    echo "Not a release branch, skipping success notification"
                }
            }
        }
        always {
            script {
                if (env.IS_RELEASE_BRANCH == 'true') {
                    try {
                        archiveArtifacts allowEmptyArchive: true, artifacts: '**/contracts/build/validator/**'
                    } catch (Exception e) {
                        println("Couldn't archive artifacts **/contracts/build/validator/**")
                    }
                }
            }
        }
    }
}

def notifyBitbucketWithState(String state) {
    echo('status: ' + state)
    if ('SUCCESS' == state || 'FAILED' == state) {
        currentBuild.result = state
    }
    notifyBitbucket()
}
