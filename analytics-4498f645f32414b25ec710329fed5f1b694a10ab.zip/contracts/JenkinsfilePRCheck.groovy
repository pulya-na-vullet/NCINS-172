def UUID_DIR = UUID.randomUUID().toString()

pipeline {
    agent {
        kubernetes {
            inheritFrom 'debian12-jdk21-node16'
            defaultContainer 'debian12-jdk21-node16-builder'
            customWorkspace UUID_DIR
        }
    }

    triggers {
        GenericTrigger(
                genericVariables: [
                        [key: 'branchName', value: '$.sourceBranchName', expressionType: 'JSONPath', defaultValue: 'master'],
                        [key: 'pullRequestTitle', value: '$.pullRequestTitle', expressionType: 'JSONPath', defaultValue: 'not title']
                ],
                causeString: '$pullRequestTitle (Запущено на ветке: $branchName)',
                token: 'analytics-pr'
        )
    }

    options {
        buildDiscarder(logRotator(daysToKeepStr: '7', artifactDaysToKeepStr: '7'))
        timeout(time: 1, unit: 'HOURS')
        ansiColor('xterm')
    }

    stages {
        stage("Reading parameters") {
            steps {
                script {
                    properties([
                            parameters([
                                    string(name: "branchName", description: "Ветка", defaultValue: 'master'),
                                    string(name: "credentialsId", description: "Реквизиты для публикации в artifactory", defaultValue: 'tech_ump_jenkins')
                            ])
                    ])
                }
            }
        }
        stage("Updating project from git") {
            steps {
                checkout([$class           : 'GitSCM',
                          branches         : [[name: "*/${branchName}"]],
                          userRemoteConfigs: [[credentialsId: 'jenkins-git', url: 'ssh://git@git.moscow.alfaintra.net/scm/ump/analytics.git']]])
            }
        }
        stage('Contract validation') {
            steps {
                script {
                    ansiColor('xterm') {
                        sh "chmod +x ./gradlew"
                        sh './gradlew contracts:validator'
                    }
                }
            }
        }
        stage('Build client without publish') {
            steps {
                script {
                    env.GRADLE_USER_HOME = "${env.WORKSPACE}/.gradle"
                    sh "export LANG=C.UTF-8 && locale"
                    sh "chmod +x ./gradlew"
                    git branch: "${params.branchName}", credentialsId: 'jenkins-git', url: 'ssh://git@git.moscow.alfaintra.net/scm/ump/analytics.git'
                    sh "./gradlew --info contracts:build --stacktrace --console=plain"
                }
            }
        }
    }
    post {
        failure {
            notifyBitbucketWithState('FAILED')
        }
        success {
            notifyBitbucketWithState('SUCCESS')
        }
        always {
            script {
                try {
                    archiveArtifacts allowEmptyArchive: true, artifacts: '**/contracts/build/validator/**'
                } catch (Exception e) {
                    println("Couldn't archive artifacts **/contracts/build/validator/**")
                }
            }
        }
    }
}

def notifyBitbucketWithState(String state) {
    echo('status: ' + state)
    if ('SUCCESS' == state || 'FAILED' == state) {
        currentBuild.result = state
    }
    notifyBitbucket()
}
