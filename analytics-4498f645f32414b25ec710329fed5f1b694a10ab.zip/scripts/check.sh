#!/bin/bash
set -eou pipefail
printf "start check script\n"
git diff --name-only HEAD^..HEAD | (grep contracts || true) | (grep -E '.yaml|.yml' || true) > files.txt
cat files.txt
# Получаем только имя ветки на которой запускается пайп (всегда это только release/*)
branch=$(git branch -r --contains HEAD | grep -v HEAD | sed 's/.*origin\///' | head -n 1)
echo "========="
echo "Branch name: " $branch
echo "========="
if [[ -s files.txt ]]; then
    # Получаем первые две цифры из релизной ветки
    release_version="$(echo "$branch" | sed -nre 's/^[^0-9]*(([0-9]+\.).).*/\1/p')"
    echo "release version: $release_version"
    version_incremented_files=0
    version_changed_files=0
    echo "begin check"
    while read line
    do
      # Если контракт поменялся, но версия не изменилась, то меняем её автоматически
        if [[ -f "$line" ]]; #проверяем валидный ли путь до файла
        then
            echo "checking for version change in $line"
            commit_version=$(git diff HEAD^..HEAD -- $line | grep "^\+  version" || true )
            if [[ -z $commit_version ]];
            then
                # Если контракт поменялся, но версия не изменилась, то меняем её автоматически
                echo "version has not changed in contract $line"
                if [[ $commit_version == "" ]];
                then
                    old="version: $(cat "$line" | grep version | sed -nre 's/^[^0-9]*(([0-9]+\.)*[0-9]+).*/\1/p')"
                    # Проверяем совпадают ли первые цифры версии контракта и релиза
                    if [[ $old == *"version: $release_version"* ]];
                    then
                      # Если первые две цифры совпадают, то увеличиваем патч версию
                      new="version: $(cat $line | grep version | sed -nre 's/^[^0-9]*(([0-9]+\.)*[0-9]+).*/\1/p' | awk -F. -v OFS=. 'NF==1{print ++$NF}; NF>1{$NF=sprintf("%0*d", length($NF), ($NF+1)); print}')"
                      sed -i "s/$old/$new/" $line
                    else
                      # Иначе указываем релизную версию с нулевой патч версией (например: 1.5.0)
                      new="version: $release_version.0"
                      sed -i "s/$old/$new/g" $line
                    fi
                    echo "automatically changed to $new in contract $line"
                    version_incremented_files=$((version_incremented_files + 1))
                fi
            else
              # Если контракт поменялся, и версия была изменина в ручную
              echo "version manually changed in contract $line"
              version_changed_files=$((version_changed_files + 1))
            fi
        else
          echo "contract $line has been removed"
        fi
    done < <(cat files.txt)
    echo "check finished"
    rm files.txt
    echo "number of contracts with automatically incremented version  = $version_incremented_files"
    echo "number of contracts with manually changed version  = $version_changed_files"
    if [[ $version_incremented_files -gt 0 ]];
    then
        echo "=======git fetch and checkout======="
        git fetch origin
        git checkout -B "${branch}" origin/"${branch}"
        echo "=======git add and commit======="
        git add -A
        git commit -m "Contract version updated"
        echo "=======git push======="
        git push origin "${branch}"
#        echo "=======git checkout======="
#        git checkout -B "${branch}"
#        echo "=======gradle distZip======="
#        ./gradlew --info contracts:distZip --stacktrace --console=plain
#        echo "=======gradle publish======="
#        ./gradlew --info contracts:publish --stacktrace --console=plain
#    else
#        if [[ $version_changed_files -gt 0 ]];
#        then
#            echo "=======git checkout======="
#            git checkout -B "${branch}"
#            echo "=======gradle distZip======="
#            ./gradlew --info contracts:distZip --stacktrace --console=plain
#            echo "=======gradle publish======="
#            ./gradlew --info contracts:publish --stacktrace --console=plain
#        fi
    fi
else
  echo "contracts have not changed"
fi
echo "end check script"