#!/bin/bash

# Проверка наличия сообщения в аргументах командной строки
if [ $# -eq 0 ]; then
    echo "Usage: $0 <channel-name>"
    exit 1
fi

if [[ -z "$ROCKET_CHAT_USER" || -z "$ROCKET_CHAT_PASS" ]]; then
  echo "❌ Ошибка: переменные ROCKET_CHAT_USER и ROCKET_CHAT_PASS не заданы"
  exit 1
fi

LOGIN_RESPONSE=$(curl -s --location 'https://rc.alfa-bank.net/api/v1/login' \
    --header 'Content-Type: application/x-www-form-urlencoded' \
    --data-urlencode "user=${ROCKET_CHAT_USER}" \
    --data-urlencode "password=${ROCKET_CHAT_PASS}")

TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"authToken":"[^"]*' | sed 's/"authToken":"//')
USER_ID=$(echo "$LOGIN_RESPONSE" | grep -o '"userId":"[^"]*' | sed 's/"userId":"//')

# Проверка на успешное получение TOKEN и USER_ID
if [[ -z "$TOKEN" || -z "$USER_ID" ]]; then
    echo "Error: Failed to retrieve TOKEN or USER_ID"
    exit 1
fi

# Установка переменных окружения
URL="https://rc.alfa-bank.net/api/v1/chat.postMessage"
CHATNAME=$1
MESSAGE=$2

GIT_DIFF=$(git diff --name-only HEAD^..HEAD)
CHAGE_NAME_FILES=$(echo "$GIT_DIFF" | sed -e ':a' -e 'N' -e '$!ba' -e 's/\n/\\n/g')
echo "$GIT_DIFF" | grep contracts | grep -E '.yaml|.yml' > getVersion.txt
version_changes=""

if [[ -s getVersion.txt ]]; then
    while IFS= read -r line; do
        FILE_PATH="$line"
        FILE_NAME=$(basename "$line" .yaml)
        if [[ -f "$FILE_PATH" ]]; then
            echo "Checking for version change in $FILE_PATH"
            commit_version=$(git diff HEAD^..HEAD -- "$FILE_PATH" | grep "^\+  version" | awk '{print $3}' || true)
            if [[ -n $commit_version ]]; then
                version_changes+="$FILE_NAME = $commit_version\n"
            else
                echo "No version change detected in $FILE_NAME"
            fi
        else
            echo "File $line does not exist"
        fi
    done < getVersion.txt
else
    echo "No YAML files in 'contracts' directory were changed."
fi

# Подготовка тела запроса
BODY="{
    \"channel\": \"$CHATNAME\",
    \"text\": \"Измененные файлы:\\n$CHAGE_NAME_FILES\\n\\nВерсии спецификаций:\n$version_changes\"
}"

# Логирование запроса
echo "======= Request Log ======="
echo "POST $URL"
echo "Body:"
echo "$BODY"
echo "================================"

# Отправка POST запроса и запись ответа
RESPONSE=$(curl -s -w "\nHTTP_CODE: %{http_code}\n" -o /tmp/curl_output.txt --location "$URL" \
    --header "X-Auth-Token: $TOKEN" \
    --header "X-User-Id: $USER_ID" \
    --header "Content-type: application/json" \
    --data "$BODY" 2>&1)

# Чтение вывода и статус-кода
CURL_OUTPUT=$(cat /tmp/curl_output.txt)
HTTP_STATUS=$(echo "$RESPONSE" | grep 'HTTP_CODE' | awk '{print $2}')

# Логирование ответа
echo "======= Response ======="
echo "$RESPONSE"
echo "$CURL_OUTPUT"
echo "============================="

# Проверка статус-кода
if [ "$HTTP_STATUS" -eq 200 ]; then
    echo "================="
    echo "Notification was sent successfully!"
    echo "================="
else
    echo "Error: Failed to send notification. HTTP Status Code: $HTTP_STATUS"
    exit 1
fi